import SafariServices
import SwiftData
import SwiftUI

// MARK: - 系统 Safari 组件（与 Safari 共享登录态）

struct SafariView: UIViewControllerRepresentable {
    let url: URL

    func makeUIViewController(context: Context) -> SFSafariViewController {
        let controller = SFSafariViewController(url: url)
        controller.dismissButtonStyle = .close
        controller.preferredBarTintColor = UIColor(CampusPalette.background)
        return controller
    }

    func updateUIViewController(_ uiViewController: SFSafariViewController, context: Context) {}
}

// MARK: - 打开某门课的学习通页面

struct ChaoxingSheet: View {
    let localTitle: String
    let localTeacher: String

    @Environment(\.dismiss) private var dismiss
    @Query private var bindings: [ChaoxingBinding]
    @State private var showBindEditor = false

    private var binding: ChaoxingBinding? {
        let key = ChaoxingBinding.key(title: localTitle, teacher: localTeacher)
        return bindings.first { $0.key == key }
    }

    private var courseURL: URL? {
        guard let text = binding?.courseURL, !text.isEmpty else { return nil }
        return URL(string: text)
    }

    var body: some View {
        if let url = courseURL {
            SafariView(url: url)
                .ignoresSafeArea()
        } else {
            NavigationStack {
                VStack(spacing: 14) {
                    Image(systemName: "link.badge.plus")
                        .font(.system(size: 44))
                        .foregroundStyle(CampusPalette.primary)

                    if let binding {
                        Text("「\(localTitle)」已绑定到 \(binding.chaoxingName)")
                            .font(.headline)
                        Text("但还没有填课程链接。在 Safari 里打开这门课，复制地址栏的完整链接，粘贴到绑定里。")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.center)
                    } else {
                        Text("「\(localTitle)」还没有绑定学习通课程")
                            .font(.headline)
                        Text("绑定后，点这张卡片会直接打开学习通的这门课。")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.center)
                    }

                    Button(binding == nil ? "去绑定" : "补充课程链接") { showBindEditor = true }
                        .buttonStyle(.borderedProminent)
                }
                .padding(24)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .navigationTitle("学习通")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("关闭") { dismiss() }
                    }
                }
                .sheet(isPresented: $showBindEditor) {
                    ChaoxingBindingEditor(
                        localTitle: localTitle,
                        localTeacher: localTeacher,
                        existing: binding
                    ) { dismiss() }
                }
            }
        }
    }
}

// MARK: - 绑定管理

struct ChaoxingBindingsView: View {
    @Environment(\.modelContext) private var context
    @Query private var bindings: [ChaoxingBinding]

    @State private var editing: ChaoxingBinding?
    @State private var showNew = false

    private var rows: [ChaoxingBinding] {
        bindings.sorted { $0.localTitle < $1.localTitle }
    }

    var body: some View {
        List {
            Section {
                ForEach(rows) { item in
                    VStack(alignment: .leading, spacing: 4) {
                        Text(item.localTitle).font(.headline)
                        Text("→ \(item.chaoxingName)")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                        Text(item.courseURL.isEmpty ? "未填课程链接" : "已填课程链接")
                            .font(.caption2)
                            .foregroundStyle(item.courseURL.isEmpty ? .orange : .tertiary)
                    }
                    .contentShape(Rectangle())
                    .onTapGesture { editing = item }
                    .swipeActions {
                        Button("删除", role: .destructive) {
                            context.delete(item)
                            try? context.save()
                        }
                    }
                }
            } footer: {
                Text("课程链接里带 enc 参数，它会随时间变化。如果某天打不开，重新复制一条新链接，点这里更新即可。链接只存本机，不会导出到备份。")
            }

            Section {
                Button("新增绑定") { showNew = true }
            }
        }
        .navigationTitle("学习通绑定")
        .sheet(isPresented: $showNew) {
            ChaoxingBindingEditor(localTitle: "", localTeacher: "", existing: nil) {}
        }
        .sheet(item: $editing) { item in
            ChaoxingBindingEditor(
                localTitle: item.localTitle,
                localTeacher: item.localTeacher,
                existing: item
            ) {}
        }
    }
}

// MARK: - 绑定编辑器

struct ChaoxingBindingEditor: View {
    let localTitle: String
    let localTeacher: String
    let existing: ChaoxingBinding?
    var onSaved: () -> Void = {}

    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @Query private var courses: [CampusCourse]

    @State private var title = ""
    @State private var teacher = ""
    @State private var chaoxingName = ""
    @State private var courseURL = ""
    @State private var courseId = ""
    @State private var clazzId = ""

    private var localTitles: [String] {
        Array(Set(courses.map(\.title))).sorted()
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("本地课程") {
                    TextField("课程名称", text: $title)
                    if !localTitles.isEmpty {
                        Menu("从课表选择") {
                            ForEach(localTitles, id: \.self) { name in
                                Button(name) { title = name }
                            }
                        }
                    }
                    TextField("任课教师（可选，用于区分同名课）", text: $teacher)
                }

                Section {
                    TextField("学习通上的课程名称", text: $chaoxingName)
                } header: {
                    Text("学习通课程")
                } footer: {
                    Text("例如「261学期 程序设计基础」。")
                }

                Section {
                    TextField("粘贴完整课程链接", text: $courseURL, axis: .vertical)
                        .lineLimit(3...6)
                        .onChange(of: courseURL) { _, newValue in
                            parseIDs(from: newValue)
                        }
                    if !courseId.isEmpty {
                        LabeledContent("courseid", value: courseId)
                    }
                    if !clazzId.isEmpty {
                        LabeledContent("clazzid", value: clazzId)
                    }
                } header: {
                    Text("课程链接")
                } footer: {
                    Text("在 Safari 打开这门课，复制地址栏的完整链接粘到这里。链接里的 enc 会过期，失效时重新复制一条覆盖即可。")
                }

                if existing != nil {
                    Section {
                        Button("解除绑定", role: .destructive) {
                            if let existing { context.delete(existing); try? context.save() }
                            onSaved()
                            dismiss()
                        }
                    }
                }
            }
            .navigationTitle(existing == nil ? "新增绑定" : "编辑绑定")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") { save() }
                        .disabled(title.trimmingCharacters(in: .whitespaces).isEmpty ||
                                  chaoxingName.trimmingCharacters(in: .whitespaces).isEmpty ||
                                  courseURL.trimmingCharacters(in: .whitespaces).isEmpty)
                }
            }
            .onAppear {
                if let existing {
                    title = existing.localTitle
                    teacher = existing.localTeacher
                    chaoxingName = existing.chaoxingName
                    courseURL = existing.courseURL
                    courseId = existing.courseId
                    clazzId = existing.clazzId
                } else {
                    title = localTitle
                    teacher = localTeacher
                }
            }
        }
    }

    /// 从链接里解析 courseid / clazzid，方便核对
    private func parseIDs(from text: String) {
        guard let url = URL(string: text.trimmingCharacters(in: .whitespacesAndNewlines)),
              let items = URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems else { return }
        for item in items {
            if item.name == "courseid", let value = item.value { courseId = value }
            if item.name == "clazzid", let value = item.value { clazzId = value }
        }
    }

    private func save() {
        let t = title.trimmingCharacters(in: .whitespaces)
        let tc = teacher.trimmingCharacters(in: .whitespaces)
        let name = chaoxingName.trimmingCharacters(in: .whitespaces)
        let link = courseURL.trimmingCharacters(in: .whitespacesAndNewlines)

        if let existing {
            existing.localTitle = t
            existing.localTeacher = tc
            existing.chaoxingName = name
            existing.courseURL = link
            existing.courseId = courseId
            existing.clazzId = clazzId
            existing.updatedAt = .now
        } else {
            context.insert(
                ChaoxingBinding(
                    localTitle: t,
                    localTeacher: tc,
                    chaoxingName: name,
                    courseURL: link,
                    courseId: courseId,
                    clazzId: clazzId
                )
            )
        }
        try? context.save()
        onSaved()
        dismiss()
    }
}
