import SafariServices
import SwiftData
import SwiftUI
import UIKit

/// 系统 Safari 组件：与 Safari 共享学习通登录态，不在本 App 内保存账号。
struct SafariView: UIViewControllerRepresentable {
    let url: URL

    func makeUIViewController(context: Context) -> SFSafariViewController {
        let controller = SFSafariViewController(url: url)
        controller.dismissButtonStyle = .close
        controller.preferredBarTintColor = UIColor(CampusPalette.background)
        return controller
    }

    func updateUIViewController(_ uiViewController: SFSafariViewController, context: Context) {}
}

// MARK: - 绑定管理

struct ChaoxingBindingsView: View {
    @Environment(\.modelContext) private var context
    @Query private var bindings: [ChaoxingBinding]
    @State private var editing: ChaoxingBinding?
    @State private var showNew = false

    private var rows: [ChaoxingBinding] {
        bindings.sorted { $0.localTitle < $1.localTitle }
    }

    var body: some View {
        List {
            ForEach(rows) { item in
                VStack(alignment: .leading, spacing: 3) {
                    Text(item.localTitle).font(.subheadline.weight(.medium))
                    Text("→ \(item.chaoxingName)")
                        .font(.caption).foregroundStyle(.secondary)
                    Text(item.courseURL.isEmpty ? "未填课程链接" : "已填课程链接")
                        .font(.caption2)
                        .foregroundStyle(item.courseURL.isEmpty ? Color.orange : Color.secondary)
                }
                .padding(.vertical, 3)
                .contentShape(Rectangle())
                .onTapGesture { editing = item }
                .swipeActions {
                    Button("删除", role: .destructive) {
                        context.delete(item)
                        try? context.save()
                    }
                }
            }
            Section {
                Button("新增绑定") { showNew = true }
            } footer: {
                Text("课程链接里的 enc 会过期，打不开时重新复制一条覆盖即可。链接只存本机，不导出到备份。")
            }
        }
        .navigationTitle("学习通绑定")
        .navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $showNew) {
            ChaoxingBindingEditor(localTitle: "", localTeacher: "", existing: nil)
        }
        .sheet(item: $editing) { item in
            ChaoxingBindingEditor(
                localTitle: item.localTitle,
                localTeacher: item.localTeacher,
                existing: item
            )
        }
    }
}

// MARK: - 绑定编辑器

struct ChaoxingBindingEditor: View {
    let localTitle: String
    let localTeacher: String
    let existing: ChaoxingBinding?

    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @Query private var courses: [CampusCourse]

    @State private var title = ""
    @State private var teacher = ""
    @State private var chaoxingName = ""
    @State private var courseURL = ""

    private var localTitles: [String] {
        Array(Set(courses.map(\.title))).sorted()
    }

    private var canSave: Bool {
        !title.trimmingCharacters(in: .whitespaces).isEmpty &&
        !chaoxingName.trimmingCharacters(in: .whitespaces).isEmpty &&
        !courseURL.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("本地课程") {
                    TextField("课程名称", text: $title)
                    if !localTitles.isEmpty {
                        Menu("从课表选择") {
                            ForEach(localTitles, id: \.self) { name in
                                Button(name) { title = name }
                            }
                        }
                    }
                    TextField("任课教师（可选）", text: $teacher)
                }

                Section {
                    TextField("学习通上的课程名称", text: $chaoxingName)
                    TextField("粘贴完整课程链接", text: $courseURL, axis: .vertical)
                        .lineLimit(2...4)
                } header: {
                    Text("学习通课程")
                } footer: {
                    Text("在 Safari 打开这门课，复制地址栏的完整链接粘到这里。")
                }

                if existing != nil {
                    Section {
                        Button("解除绑定", role: .destructive) {
                            if let existing { context.delete(existing); try? context.save() }
                            dismiss()
                        }
                    }
                }
            }
            .navigationTitle(existing == nil ? "新增绑定" : "编辑绑定")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") { save() }.disabled(!canSave)
                }
            }
            .onAppear {
                if let existing {
                    title = existing.localTitle
                    teacher = existing.localTeacher
                    chaoxingName = existing.chaoxingName
                    courseURL = existing.courseURL
                } else {
                    title = localTitle
                    teacher = localTeacher
                }
            }
        }
    }

    private func save() {
        let t = title.trimmingCharacters(in: .whitespaces)
        let tc = teacher.trimmingCharacters(in: .whitespaces)
        let name = chaoxingName.trimmingCharacters(in: .whitespaces)
        let link = courseURL.trimmingCharacters(in: .whitespacesAndNewlines)

        if let existing {
            existing.localTitle = t
            existing.localTeacher = tc
            existing.chaoxingName = name
            existing.courseURL = link
            existing.updatedAt = .now
        } else {
            context.insert(
                ChaoxingBinding(
                    localTitle: t,
                    localTeacher: tc,
                    chaoxingName: name,
                    courseURL: link
                )
            )
        }
        try? context.save()
        dismiss()
    }
}
