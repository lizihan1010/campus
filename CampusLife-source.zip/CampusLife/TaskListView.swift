import SwiftData
import SwiftUI

struct TaskListView: View {
    @Query(sort: \CampusTask.dueAt) private var tasks: [CampusTask]
    @Environment(\.modelContext) private var context
    @AppStorage("termStartTimestamp") private var termStartTimestamp = 0.0
    @State private var showNew = false
    @State private var editing: CampusTask?

    var body: some View {
        List {
            if tasks.isEmpty {
                EmptyMessage(symbol: "checklist", title: "还没有待办", message: "添加作业、活动或生活事项。")
                    .listRowBackground(Color.clear)
            }
            ForEach(tasks) { task in
                HStack(alignment: .top, spacing: 12) {
                    Button {
                        task.isDone.toggle()
                        try? context.save()
                        rebuildReminders()
                    } label: {
                        Image(systemName: task.isDone ? "checkmark.circle.fill" : "circle")
                            .font(.title3)
                            .foregroundStyle(CampusPalette.primary)
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel(task.isDone ? "恢复\(task.title)" : "完成\(task.title)")
                    VStack(alignment: .leading, spacing: 4) {
                        Text(task.title).font(.headline).strikethrough(task.isDone)
                        Text(task.dueAt, format: .dateTime.month().day().hour().minute())
                            .font(.subheadline).foregroundStyle(.secondary)
                        if !task.details.isEmpty { Text(task.details).font(.footnote).foregroundStyle(.secondary) }
                    }
                    Spacer()
                    Button { editing = task } label: { Image(systemName: "pencil") }
                        .accessibilityLabel("编辑\(task.title)")
                }
            }
            .onDelete { offsets in
                for index in offsets { context.delete(tasks[index]) }
                try? context.save()
                rebuildReminders()
            }
        }
        .navigationTitle("全部待办")
        .toolbar { ToolbarItem(placement: .topBarTrailing) { Button { showNew = true } label: { Image(systemName: "plus") } } }
        .sheet(isPresented: $showNew) { TaskEditor() }
        .sheet(item: $editing) { TaskEditor(task: $0) }
    }

    private func rebuildReminders() {
        let start = termStartTimestamp > 0 ? Date(timeIntervalSince1970: termStartTimestamp) : .now
        Task { await ReminderManager.rebuildFrom(context: context, termStart: start) }
    }
}
