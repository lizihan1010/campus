import Foundation

/// 把教务系统「列表」视图的表格解析成课程
enum TimetableParser {

    struct Item {
        var weekday: Int
        var periods: [Int]
        var weeks: [Int]
        var location: String
    }

    /// rows 是网页表格的纯文本（第一行是表头）
    static func parse(rows: [[String]]) -> (courses: [ParsedCourse], skipped: Int) {
        guard let headerRow = rows.first(where: { row in row.contains { normalize($0).contains("上课时间地点") } }) else {
            return ([], 0)
        }

        let header = headerRow.map(normalize)
        guard let timeCol = header.firstIndex(where: { $0.contains("上课时间地点") }),
              let courseCol = header.firstIndex(where: { $0.contains("课程") }),
              let teacherCol = header.firstIndex(where: { $0.contains("任课教师") })
        else { return ([], 0) }

        var courses: [ParsedCourse] = []
        var skipped = 0

        for row in rows {
            guard row.count > max(courseCol, max(teacherCol, timeCol)) else { continue }

            let timeText = normalize(row[timeCol])
            guard timeText.contains("周") else { continue }

            let title = name(from: row[courseCol])
            guard !title.isEmpty else { continue }
            let teacher = name(from: row[teacherCol])

            var parsedAny = false
            for segment in splitSegments(timeText) {
                guard let item = parseSegment(segment) else { continue }
                parsedAny = true
                let range = PeriodTable.range(item.periods)
                courses.append(
                    ParsedCourse(
                        title: title,
                        teacher: teacher,
                        location: item.location,
                        weekday: item.weekday,
                        startMinute: range.start,
                        endMinute: range.end,
                        weeks: item.weeks
                    )
                )
            }

            if !parsedAny { skipped += 1 }   // 线上课、无固定时间的课
        }

        return (courses, skipped)
    }

    // MARK: - 内部

    private static func normalize(_ text: String) -> String {
        text.replacingOccurrences(of: "\u{00A0}", with: " ")
            .split(whereSeparator: { $0.isWhitespace || $0.isNewline })
            .joined(separator: " ")
            .trimmingCharacters(in: .whitespaces)
    }

    /// "[1014300154]程序设计基础" → "程序设计基础"
    private static func name(from text: String) -> String {
        let value = normalize(text)
        if let close = value.firstIndex(of: "]") {
            return String(value[value.index(after: close)...]).trimmingCharacters(in: .whitespaces)
        }
        return value
    }

    private static func splitSegments(_ text: String) -> [String] {
        text.replacingOccurrences(of: "，", with: ",")
            .split(separator: ",")
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { $0.contains("周") }
    }

    private static let segmentRegex = try! NSRegularExpression(
        pattern: "([0-9,\\-]+(?:\\((?:单|双)\\))?)\\s*周\\s*([一二三四五六日天])\\s*\\[\\s*([0-9,\\-]*)\\s*\\]\\s*(.*)",
        options: []
    )

    private static let weekdayMap: [Character: Int] = [
        "一": 1, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6, "日": 7, "天": 7
    ]

    static func parseSegment(_ text: String) -> Item? {
        let ns = text as NSString
        guard let match = segmentRegex.firstMatch(in: text, range: NSRange(location: 0, length: ns.length)) else {
            return nil
        }

        func group(_ index: Int) -> String {
            let range = match.range(at: index)
            guard range.location != NSNotFound else { return "" }
            return ns.substring(with: range)
        }

        let weeks = TimetableSync.weeks(from: group(1))
        let weekdayText = group(2)
        let periods = TimetableSync.periods(from: group(3))

        guard !weeks.isEmpty, !periods.isEmpty,
              let weekday = weekdayText.first.flatMap({ weekdayMap[$0] }) else { return nil }

        var location = group(4)
        location = location.replacingOccurrences(of: "\\((\\d+)\\)", with: "", options: .regularExpression)
        location = location.replacingOccurrences(of: "\\([^)]*校区\\)", with: "", options: .regularExpression)
        location = location.trimmingCharacters(in: .whitespaces)

        return Item(weekday: weekday, periods: periods, weeks: weeks, location: location)
    }

    // MARK: - 网页提取脚本

    /// 在课表页面里执行，返回 JSON：{"ok":true,"tables":[[[单元格文字]]]}
    static let extractionScript = """
    (function () {
      function collect(doc, out) {
        try {
          var tables = doc.querySelectorAll('table');
          for (var i = 0; i < tables.length; i++) {
            var t = tables[i];
            var text = t.innerText || '';
            if (text.indexOf('上课时间地点') === -1) continue;
            var rows = [];
            var trs = t.querySelectorAll('tr');
            for (var r = 0; r < trs.length; r++) {
              var cells = [];
              var children = trs[r].children;
              for (var c = 0; c < children.length; c++) {
                cells.push((children[c].innerText || '').trim());
              }
              if (cells.length) rows.push(cells);
            }
            if (rows.length) out.push(rows);
          }
          var frames = doc.querySelectorAll('iframe,frame');
          for (var f = 0; f < frames.length; f++) {
            try {
              if (frames[f].contentDocument) collect(frames[f].contentDocument, out);
            } catch (e) {}
          }
        } catch (e) {}
      }
      var out = [];
      collect(document, out);
      return JSON.stringify({ ok: out.length > 0, tables: out });
    })();
    """
}
