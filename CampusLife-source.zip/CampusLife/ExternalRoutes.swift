import SwiftUI
import UIKit
import VisionKit

enum CampusService: String, CaseIterable, Identifiable {
    case signIn, water, timetable, sports, shower

    var id: String { rawValue }

    var title: String {
        switch self {
        case .signIn: "扫码签到"
        case .water: "喝水"
        case .timetable: "原课表"
        case .sports: "运动"
        case .shower: "洗澡"
        }
    }

    var symbol: String {
        switch self {
        case .signIn: "qrcode.viewfinder"
        case .water: "drop.fill"
        case .timetable: "calendar"
        case .sports: "figure.run"
        case .shower: "shower.fill"
        }
    }

    var shortcut: String? {
        switch self {
        case .water: "校园-喝水"
        case .timetable: "校园-课表"
        case .sports: "校园-运动"
        default: nil
        }
    }

    var guidance: String {
        switch self {
        case .signIn: "在微信搜索并打开“修猫助手”，进入扫码签到。按小程序要求由本人完成照片、位置和扫码。"
        case .water: "将“校园-喝水”快捷指令设置为打开慧生活798。进入后点首页顶部“扫一扫”，付款由你本人确认。"
        case .timetable: "将“校园-课表”快捷指令设置为打开喜鹊儿。进入后点底部“我的课表”。"
        case .sports: "如“打开 App”动作能选到创高体育，请创建“校园-运动”快捷指令并在真机验证。内部运动打卡页仍需手动进入。"
        case .shower: "点击即可尝试打开常用洗浴设备页面；下单和付款仍由你在原服务确认。"
        }
    }

    var status: String {
        switch self {
        case .signIn: "微信内操作"
        case .sports: "待验证"
        case .shower: "直达常用设备"
        case .water: "打开慧生活798"
        case .timetable: "打开原 App"
        }
    }
}

@MainActor
enum ExternalRoutes {
    static func runShortcut(_ name: String) async -> Bool {
        var parts = URLComponents()
        parts.scheme = "shortcuts"
        parts.host = "run-shortcut"
        parts.queryItems = [URLQueryItem(name: "name", value: name)]
        guard let url = parts.url else { return false }
        return await UIApplication.shared.open(url)
    }

    nonisolated static func showerURL(from raw: String) -> URL? {
        let value = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URL(string: value), let scheme = url.scheme?.lowercased(),
              !["file", "data", "javascript", "shortcuts", "itms-services"].contains(scheme) else { return nil }
        if scheme == "http" || scheme == "https" {
            guard url.host != nil else { return nil }
        }
        return url
    }
}

struct ServiceSheet: View {
    let service: CampusService
    @Environment(\.dismiss) private var dismiss
    @State private var feedback: String?
    @State private var showerLink = ShowerLinkStore.load()
    @State private var showShowerScanner = false
    @State private var showerScanMessage: String?
    @State private var scannedShowerCode: String?

    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 20) {
                Image(systemName: service.symbol)
                    .font(.system(size: 36))
                    .foregroundStyle(CampusPalette.primary)
                    .frame(width: 72, height: 72)
                    .background(CampusPalette.primary.opacity(0.10), in: RoundedRectangle(cornerRadius: 20))
                Text(service.title).font(.largeTitle.bold())
                Text(service.guidance).font(.body).foregroundStyle(.secondary)
                if service == .signIn {
                    Button("复制小程序名称：修猫助手") {
                        UIPasteboard.general.string = "修猫助手"
                        feedback = "已复制；请到微信搜索"
                    }
                    .buttonStyle(.borderedProminent)
                } else if service == .shower {
                    if let showerLink, let url = ExternalRoutes.showerURL(from: showerLink) {
                        Button("打开洗浴下单页") {
                            Task {
                                let opened = await UIApplication.shared.open(url)
                                feedback = opened ? "已请求打开，请确认进入的是这台设备的下单页" : "未能打开该入口，请重新扫描设备二维码"
                            }
                        }
                        .buttonStyle(.borderedProminent)
                        Button("扫描更换设备") { presentShowerScanner() }
                        if showerLink != ShowerLinkStore.defaultLink {
                            Button("恢复默认设备 2153544") {
                                ShowerLinkStore.remove()
                                self.showerLink = ShowerLinkStore.load()
                                feedback = "已恢复默认设备"
                            }
                        }
                    } else {
                        Button("扫描设备二维码") { presentShowerScanner() }
                            .buttonStyle(.borderedProminent)
                    }
                } else if let shortcut = service.shortcut {
                    Button(service == .water ? "打开慧生活798" : service == .sports ? "尝试打开 \(service.title)" : "打开 \(service.title)") {
                        Task {
                            let opened = await ExternalRoutes.runShortcut(shortcut)
                            feedback = opened ? "已请求运行快捷指令；若未打开，请检查快捷指令名称" : "无法打开快捷指令，请检查是否安装并配置"
                        }
                    }
                    .buttonStyle(.borderedProminent)
                }
                if let feedback {
                    Text(feedback).font(.footnote).foregroundStyle(CampusPalette.primary)
                }
                Spacer()
            }
            .padding(24)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(CampusPalette.background)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("完成") { dismiss() } } }
        }
        .presentationDetents([.medium, .large])
        .sheet(isPresented: $showShowerScanner) {
            NavigationStack {
                ShowerQRScanner { raw in
                    scannedShowerCode = raw
                    guard let url = ExternalRoutes.showerURL(from: raw) else {
                        showerScanMessage = "已识别二维码，但内容不是可直接打开的链接。请复制识别结果发给我，我会核对住理生活的跳转方式。"
                        return false
                    }
                    guard ShowerLinkStore.save(url.absoluteString) else {
                        showerScanMessage = "已识别二维码，但保存入口失败。请重试。"
                        return false
                    }
                    showerLink = url.absoluteString
                    showShowerScanner = false
                    feedback = "已保存设备入口。请点“打开洗浴下单页”验证是否直达正确设备"
                    return true
                }
                .navigationTitle("扫描设备二维码")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("取消") { showShowerScanner = false } } }
            }
            .presentationDetents([.large])
            .alert("扫码结果", isPresented: Binding(
                get: { showerScanMessage != nil },
                set: { if !$0 { showerScanMessage = nil } }
            )) {
                if scannedShowerCode != nil {
                    Button("复制识别结果") {
                        UIPasteboard.general.string = scannedShowerCode
                        showerScanMessage = nil
                        showShowerScanner = false
                    }
                }
                Button("重新扫描") { showerScanMessage = nil }
            } message: {
                Text(showerScanMessage ?? "")
            }
        }
    }

    private func presentShowerScanner() {
        guard DataScannerViewController.isSupported, DataScannerViewController.isAvailable else {
            feedback = "此设备暂时无法使用相机扫码，请检查相机权限"
            return
        }
        scannedShowerCode = nil
        showerScanMessage = nil
        showShowerScanner = true
    }
}

private struct ShowerQRScanner: UIViewControllerRepresentable {
    let onScan: (String) -> Bool

    func makeCoordinator() -> Coordinator { Coordinator(onScan: onScan) }

    func makeUIViewController(context: Context) -> DataScannerViewController {
        let scanner = DataScannerViewController(
            recognizedDataTypes: [.barcode(symbologies: [.qr])],
            qualityLevel: .accurate,
            recognizesMultipleItems: false,
            isHighFrameRateTrackingEnabled: false,
            isPinchToZoomEnabled: true,
            isGuidanceEnabled: true,
            isHighlightingEnabled: true
        )
        scanner.delegate = context.coordinator
        return scanner
    }

    func updateUIViewController(_ scanner: DataScannerViewController, context: Context) {
        DispatchQueue.main.async {
            if !scanner.isScanning { try? scanner.startScanning() }
        }
    }

    final class Coordinator: NSObject, DataScannerViewControllerDelegate {
        let onScan: (String) -> Bool
        private var completed = false

        init(onScan: @escaping (String) -> Bool) { self.onScan = onScan }

        func dataScanner(_ dataScanner: DataScannerViewController, didAdd addedItems: [RecognizedItem], allItems: [RecognizedItem]) {
            guard let item = addedItems.first else { return }
            accept(item, scanner: dataScanner)
        }

        func dataScanner(_ dataScanner: DataScannerViewController, didTapOn item: RecognizedItem) {
            accept(item, scanner: dataScanner)
        }

        private func accept(_ item: RecognizedItem, scanner: DataScannerViewController) {
            guard !completed, case .barcode(let code) = item, let raw = code.payloadStringValue else { return }
            if onScan(raw) {
                completed = true
                scanner.stopScanning()
            }
        }
    }
}
