import SwiftUI
import UIKit
import VisionKit

/// 用户在微信里复制到的真实 Short Link。
/// 微信官方文档：Short Link 只用于「微信内拉起小程序」，是纯文本口令而非 URL，
/// 由小程序管理员通过服务端接口生成，短期有效版本 30 天过期。
enum WeChatShortLink {
    static let signIn = "#小程序://修猫助手/ScC15pcInDDpQej"
}

/// 服务全集。首页「常用入口」只展示 quickEntries；
/// 扫码签到保留在课程详情，「原课表」按应要求整体删除（含喜鹊儿快捷指令）。
enum CampusService: String, CaseIterable, Identifiable {
    case water, sports, shower, signIn

    var id: String { rawValue }

    /// 首页常用入口：喝水、洗澡、运动。应要求移除了「扫码签到」和「原课表」。
    static let quickEntries: [CampusService] = [.water, .sports, .shower]

    var title: String {
        switch self {
        case .signIn: "扫码签到"
        case .water: "喝水"
        case .sports: "运动"
        case .shower: "洗澡"
        }
    }

    var symbol: String {
        switch self {
        case .signIn: "qrcode.viewfinder"
        case .water: "drop.fill"
        case .sports: "figure.run"
        case .shower: "shower.fill"
        }
    }

    var shortcut: String? {
        switch self {
        case .water: "校园-喝水"
        case .sports: "校园-运动"
        default: nil
        }
    }

    var guidance: String {
        switch self {
        case .signIn: "复制修猫助手口令 → 打开微信 → 聊天框粘贴 → 点开小程序卡片。照片、位置与扫码由你本人完成。"
        case .water: "一次点击启动慧生活798。设备参数只由原 App 的「扫一扫」解析，系统相机扫同一张码只会回到首页；付款由本人确认。"
        case .sports: "在快捷指令里用「打开 App」动作选择创高体育，命名为「校园-运动」。是否能直接落到运动打卡页，需要你在真机上验证；本 App 只负责启动。"
        case .shower: "打开常用洗浴设备页面；下单和付款仍由你在原服务确认。"
        }
    }

    var status: String {
        switch self {
        case .signIn: "微信内"
        case .water: "启动原 App"
        case .sports: "待验证"
        case .shower: "直达设备"
        }
    }
}

@MainActor
enum ExternalRoutes {
    static func runShortcut(_ name: String) async -> Bool {
        var parts = URLComponents()
        parts.scheme = "shortcuts"
        parts.host = "run-shortcut"
        parts.queryItems = [URLQueryItem(name: "name", value: name)]
        guard let url = parts.url else { return false }
        return await UIApplication.shared.open(url)
    }

    nonisolated static func showerURL(from raw: String) -> URL? {
        let value = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URL(string: value), let scheme = url.scheme?.lowercased(),
              !["file", "data", "javascript", "shortcuts", "itms-services"].contains(scheme) else { return nil }
        if scheme == "http" || scheme == "https" {
            guard url.host != nil else { return nil }
        }
        return url
    }
}

struct ServiceSheet: View {
    let service: CampusService
    @Environment(\.dismiss) private var dismiss
    @State private var feedback: String?
    @State private var showerLink = ShowerLinkStore.load()
    @State private var showShowerScanner = false
    @State private var showerScanMessage: String?
    @State private var scannedShowerCode: String?

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    Label(service.title, systemImage: service.symbol)
                        .font(.title2.bold())
                        .foregroundStyle(CampusPalette.primary)
                    Text(service.guidance)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)

                    if service == .signIn {
                        Text(WeChatShortLink.signIn)
                            .font(.caption.monospaced())
                            .foregroundStyle(.secondary)
                            .textSelection(.enabled)
                        Button("复制修猫助手口令") {
                            UIPasteboard.general.string = WeChatShortLink.signIn
                            feedback = "已复制。请打开微信，在任意聊天框长按粘贴并点开卡片。"
                        }
                        .buttonStyle(PrimaryActionStyle())
                        Text("口令只在微信内生效，短期版本 30 天后可能过期；失效时请在微信重新复制并更新 WeChatShortLink.signIn。")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    } else if service == .shower {
                        if let showerLink, let url = ExternalRoutes.showerURL(from: showerLink) {
                            Button("打开洗浴下单页") {
                                Task {
                                    let opened = await UIApplication.shared.open(url)
                                    feedback = opened ? "已请求打开，请确认是这台设备的下单页" : "未能打开该入口，请重新扫描设备二维码"
                                }
                            }
                            .buttonStyle(PrimaryActionStyle())
                            Button("扫描更换设备") { presentShowerScanner() }
                                .font(.subheadline)
                            if showerLink != ShowerLinkStore.defaultLink {
                                Button("恢复默认设备 2153544") {
                                    ShowerLinkStore.remove()
                                    self.showerLink = ShowerLinkStore.load()
                                    feedback = "已恢复默认设备"
                                }
                                .font(.subheadline)
                            }
                        } else {
                            Button("扫描设备二维码") { presentShowerScanner() }
                                .buttonStyle(PrimaryActionStyle())
                        }
                    } else if let shortcut = service.shortcut {
                        Button("打开 \(service.title)") {
                            Task {
                                let opened = await ExternalRoutes.runShortcut(shortcut)
                                feedback = opened ? "已请求运行快捷指令" : "无法打开，请检查「\(shortcut)」是否已创建"
                            }
                        }
                        .buttonStyle(PrimaryActionStyle())
                        if service == .sports {
                            Text("此入口尚未取得可用的深链，快捷指令只能启动原 App；运动打卡页请在原 App 内自行进入。")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }

                    if let feedback {
                        Text(feedback).font(.footnote).foregroundStyle(CampusPalette.primary)
                    }
                }
                .padding(20)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .background(CampusPalette.background)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("完成") { dismiss() } } }
        }
        .presentationDetents([.medium, .large])
        .sheet(isPresented: $showShowerScanner) {
            NavigationStack {
                ShowerQRScanner { raw in
                    scannedShowerCode = raw
                    guard let url = ExternalRoutes.showerURL(from: raw) else {
                        showerScanMessage = "已识别二维码，但内容不是可直接打开的链接。请复制识别结果核对跳转方式。"
                        return false
                    }
                    guard ShowerLinkStore.save(url.absoluteString) else {
                        showerScanMessage = "保存入口失败，请重试。"
                        return false
                    }
                    showerLink = url.absoluteString
                    showShowerScanner = false
                    feedback = "已保存设备入口，请点「打开洗浴下单页」验证"
                    return true
                }
                .navigationTitle("扫描设备二维码")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("取消") { showShowerScanner = false } } }
            }
            .presentationDetents([.large])
            .alert("扫码结果", isPresented: Binding(
                get: { showerScanMessage != nil },
                set: { if !$0 { showerScanMessage = nil } }
            )) {
                if scannedShowerCode != nil {
                    Button("复制识别结果") {
                        UIPasteboard.general.string = scannedShowerCode
                        showerScanMessage = nil
                        showShowerScanner = false
                    }
                }
                Button("重新扫描") { showerScanMessage = nil }
            } message: {
                Text(showerScanMessage ?? "")
            }
        }
    }

    private func presentShowerScanner() {
        guard DataScannerViewController.isSupported, DataScannerViewController.isAvailable else {
            feedback = "此设备暂时无法使用相机扫码，请检查相机权限"
            return
        }
        scannedShowerCode = nil
        showerScanMessage = nil
        showShowerScanner = true
    }
}

private struct ShowerQRScanner: UIViewControllerRepresentable {
    let onScan: (String) -> Bool

    func makeCoordinator() -> Coordinator { Coordinator(onScan: onScan) }

    func makeUIViewController(context: Context) -> DataScannerViewController {
        let scanner = DataScannerViewController(
            recognizedDataTypes: [.barcode(symbologies: [.qr])],
            qualityLevel: .accurate,
            recognizesMultipleItems: false,
            isHighFrameRateTrackingEnabled: false,
            isPinchToZoomEnabled: true,
            isGuidanceEnabled: true,
            isHighlightingEnabled: true
        )
        scanner.delegate = context.coordinator
        return scanner
    }

    func updateUIViewController(_ scanner: DataScannerViewController, context: Context) {
        DispatchQueue.main.async {
            if !scanner.isScanning { try? scanner.startScanning() }
        }
    }

    final class Coordinator: NSObject, DataScannerViewControllerDelegate {
        let onScan: (String) -> Bool
        private var completed = false

        init(onScan: @escaping (String) -> Bool) { self.onScan = onScan }

        func dataScanner(_ dataScanner: DataScannerViewController, didAdd addedItems: [RecognizedItem], allItems: [RecognizedItem]) {
            guard let item = addedItems.first else { return }
            accept(item, scanner: dataScanner)
        }

        func dataScanner(_ dataScanner: DataScannerViewController, didTapOn item: RecognizedItem) {
            accept(item, scanner: dataScanner)
        }

        private func accept(_ item: RecognizedItem, scanner: DataScannerViewController) {
            guard !completed, case .barcode(let code) = item, let raw = code.payloadStringValue else { return }
            if onScan(raw) {
                completed = true
                scanner.stopScanning()
            }
        }
    }
}
