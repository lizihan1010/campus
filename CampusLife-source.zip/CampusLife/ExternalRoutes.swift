import SwiftUI
import UIKit

enum CampusService: String, CaseIterable, Identifiable {
    case signIn, water, timetable, sports, shower

    var id: String { rawValue }

    var title: String {
        switch self {
        case .signIn: "扫码签到"
        case .water: "喝水"
        case .timetable: "原课表"
        case .sports: "运动"
        case .shower: "洗澡"
        }
    }

    var symbol: String {
        switch self {
        case .signIn: "qrcode.viewfinder"
        case .water: "drop.fill"
        case .timetable: "calendar"
        case .sports: "figure.run"
        case .shower: "shower.fill"
        }
    }

    var shortcut: String? {
        switch self {
        case .water: "校园-喝水"
        case .timetable: "校园-课表"
        case .sports: "校园-运动"
        case .shower: "校园-洗澡"
        default: nil
        }
    }

    var guidance: String {
        switch self {
        case .signIn: "在微信搜索并打开“修猫助手”，进入扫码签到。按小程序要求由本人完成照片、位置和扫码。"
        case .water: "将“校园-喝水”快捷指令设置为打开慧生活789。进入后点首页顶部“扫一扫”，付款由你本人确认。"
        case .timetable: "将“校园-课表”快捷指令设置为打开喜鹊儿。进入后点底部“我的课表”。"
        case .sports: "如“打开 App”动作能选到创高体育，请创建“校园-运动”快捷指令并在真机验证。内部运动打卡页仍需手动进入。"
        case .shower: "如“打开 App”动作能选到理住生活，请创建“校园-洗澡”快捷指令并在真机验证。内部洗澡页仍需手动进入。"
        }
    }

    var status: String {
        switch self {
        case .signIn: "微信内操作"
        case .sports, .shower: "待验证"
        case .water, .timetable: "打开原 App"
        }
    }
}

@MainActor
enum ExternalRoutes {
    static func runShortcut(_ name: String) async -> Bool {
        var parts = URLComponents()
        parts.scheme = "shortcuts"
        parts.host = "run-shortcut"
        parts.queryItems = [URLQueryItem(name: "name", value: name)]
        guard let url = parts.url else { return false }
        return await UIApplication.shared.open(url)
    }
}

struct ServiceSheet: View {
    let service: CampusService
    @Environment(\.dismiss) private var dismiss
    @State private var feedback: String?

    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 20) {
                Image(systemName: service.symbol)
                    .font(.system(size: 36))
                    .foregroundStyle(CampusPalette.primary)
                    .frame(width: 72, height: 72)
                    .background(CampusPalette.primary.opacity(0.10), in: RoundedRectangle(cornerRadius: 20))
                Text(service.title).font(.largeTitle.bold())
                Text(service.guidance).font(.body).foregroundStyle(.secondary)
                if service == .signIn {
                    Button("复制小程序名称：修猫助手") {
                        UIPasteboard.general.string = "修猫助手"
                        feedback = "已复制；请到微信搜索"
                    }
                    .buttonStyle(.borderedProminent)
                } else if let shortcut = service.shortcut {
                    Button(service == .sports || service == .shower ? "尝试打开 \(service.title)" : "打开 \(service.title)") {
                        Task {
                            let opened = await ExternalRoutes.runShortcut(shortcut)
                            feedback = opened ? "已请求运行快捷指令；若未打开，请检查快捷指令名称" : "无法打开快捷指令，请检查是否安装并配置"
                        }
                    }
                    .buttonStyle(.borderedProminent)
                }
                if let feedback {
                    Text(feedback).font(.footnote).foregroundStyle(CampusPalette.primary)
                }
                Spacer()
            }
            .padding(24)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(CampusPalette.background)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("完成") { dismiss() } } }
        }
        .presentationDetents([.medium, .large])
    }
}
