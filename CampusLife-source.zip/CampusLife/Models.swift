import Foundation
import SwiftData

@Model
final class CampusCourse {
    var id: UUID
    var title: String
    var location: String
    var teacher: String
    var weekday: Int
    var startMinute: Int
    var endMinute: Int
    var firstWeek: Int
    var lastWeek: Int
    var weekMode: Int
    var note: String

    /// "jxufe" = 从教务系统同步来的；"manual" = 自己手动加的
    var source: String = "manual"
    /// 教务系统里的稳定标识，用于比对新增/修改/删除
    var externalKey: String = ""
    /// 精确周次列表（教务系统可能是 4,14 这种不连续周）；为空时按 firstWeek...lastWeek 计算
    var weekList: [Int] = []

    init(
        title: String,
        location: String = "",
        teacher: String = "",
        weekday: Int,
        startMinute: Int,
        endMinute: Int,
        firstWeek: Int = 1,
        lastWeek: Int = 20,
        weekMode: Int = 0,
        note: String = "",
        source: String = "manual",
        externalKey: String = "",
        weekList: [Int] = []
    ) {
        self.id = UUID()
        self.title = title
        self.location = location
        self.teacher = teacher
        self.weekday = weekday
        self.startMinute = startMinute
        self.endMinute = endMinute
        self.firstWeek = firstWeek
        self.lastWeek = lastWeek
        self.weekMode = weekMode
        self.note = note
        self.source = source
        self.externalKey = externalKey
        self.weekList = weekList
    }
}

@Model
final class CampusTask {
    var id: UUID
    var title: String
    var details: String
    var dueAt: Date
    var isDone: Bool
    var reminderMinutes: Int
    var sourceText: String
    var createdAt: Date

    init(title: String, details: String = "", dueAt: Date, reminderMinutes: Int = 60, sourceText: String = "") {
        self.id = UUID()
        self.title = title
        self.details = details
        self.dueAt = dueAt
        self.isDone = false
        self.reminderMinutes = reminderMinutes
        self.sourceText = sourceText
        self.createdAt = .now
    }
}

@Model
final class InboxNote {
    var id: UUID
    var content: String
    var source: String
    var createdAt: Date
    var isProcessed: Bool

    init(content: String, source: String) {
        self.id = UUID()
        self.content = content
        self.source = source
        self.createdAt = .now
        self.isProcessed = false
    }
}

enum TermClock {
    static let weekdays = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]

    static func monday(of date: Date) -> Date {
        var calendar = Calendar(identifier: .gregorian)
        calendar.firstWeekday = 2
        let start = calendar.startOfDay(for: date)
        let weekday = calendar.component(.weekday, from: start)
        let daysBack = (weekday + 5) % 7
        return calendar.date(byAdding: .day, value: -daysBack, to: start) ?? start
    }

    static func date(inWeekOf anchor: Date, weekday: Int) -> Date {
        Calendar.current.date(byAdding: .day, value: weekday - 1, to: monday(of: anchor)) ?? anchor
    }

    static func weekday(of date: Date) -> Int {
        (Calendar.current.component(.weekday, from: date) + 5) % 7 + 1
    }

    static func weekNumber(on date: Date, termStart: Date) -> Int {
        let days = Calendar.current.dateComponents([.day], from: monday(of: termStart), to: Calendar.current.startOfDay(for: date)).day ?? 0
        return days < 0 ? 0 : days / 7 + 1
    }

    static func occurs(_ course: CampusCourse, on date: Date, termStart: Date) -> Bool {
        let week = weekNumber(on: date, termStart: termStart)
        guard course.weekday == weekday(of: date) else { return false }
        // 有精确周次列表时优先用它（教务系统的 4,14 这种不连续周）
        if !course.weekList.isEmpty {
            return course.weekList.contains(week)
        }
        guard (course.firstWeek...course.lastWeek).contains(week) else { return false }
        return course.weekMode == 0 || (course.weekMode == 1 && week % 2 == 1) || (course.weekMode == 2 && week % 2 == 0)
    }

    static func time(_ minute: Int) -> String {
        String(format: "%02d:%02d", minute / 60, minute % 60)
    }

    static func dateTime(on date: Date, minute: Int) -> Date {
        Calendar.current.date(byAdding: .minute, value: minute, to: Calendar.current.startOfDay(for: date)) ?? date
    }
}
