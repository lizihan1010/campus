import Foundation
import SwiftData

@Model
final class CampusCourse {
    var id: UUID
    var title: String
    var location: String
    var teacher: String
    var weekday: Int
    var startMinute: Int
    var endMinute: Int
    var firstWeek: Int
    var lastWeek: Int
    var weekMode: Int
    var note: String

    /// "jxufe" = 从教务系统同步来的；"manual" = 自己手动加的
    var source: String = "manual"
    /// 教务系统里的稳定标识，用于比对新增/修改/删除
    var externalKey: String = ""
    /// 精确周次列表（教务系统可能是 4,14 这种不连续周）；为空时按 firstWeek...lastWeek 计算
    var weekList: [Int] = []
    /// 这节课的课前提醒提前量：0 = 跟随全局，-1 = 不提醒，>0 = 提前 N 分钟
    var reminderOverride: Int = 0

    init(
        title: String,
        location: String = "",
        teacher: String = "",
        weekday: Int,
        startMinute: Int,
        endMinute: Int,
        firstWeek: Int = 1,
        lastWeek: Int = 20,
        weekMode: Int = 0,
        note: String = "",
        source: String = "manual",
        externalKey: String = "",
        weekList: [Int] = [],
        reminderOverride: Int = 0
    ) {
        self.id = UUID()
        self.title = title
        self.location = location
        self.teacher = teacher
        self.weekday = weekday
        self.startMinute = startMinute
        self.endMinute = endMinute
        self.firstWeek = firstWeek
        self.lastWeek = lastWeek
        self.weekMode = weekMode
        self.note = note
        self.source = source
        self.externalKey = externalKey
        self.weekList = weekList
        self.reminderOverride = reminderOverride
    }
}

@Model
final class CampusTask {
    var id: UUID
    var title: String
    var details: String
    /// 单次任务＝截止时间；重复任务＝每次的执行时刻（只取时分）
    var dueAt: Date
    var isDone: Bool
    var reminderMinutes: Int
    var sourceText: String
    var createdAt: Date

    /// 0 = 只做一次，1 = 每周指定星期几，2 = 每隔 N 天
    var repeatKind: Int = 0
    /// 1...7，周一为 1，与 TermClock.weekday(of:) 一致
    var repeatWeekdays: [Int] = []
    /// repeatKind == 2 时的间隔天数
    var repeatInterval: Int = 2
    /// 重复规则的起算日（只取日期）
    var startDate: Date = .now
    /// 重复任务按「yyyy-MM-dd」记录已完成的那一天，不影响后续出现
    var doneDates: [String] = []

    init(
        title: String,
        details: String = "",
        dueAt: Date,
        reminderMinutes: Int = 60,
        sourceText: String = "",
        repeatKind: Int = 0,
        repeatWeekdays: [Int] = [],
        repeatInterval: Int = 2,
        startDate: Date = .now
    ) {
        self.id = UUID()
        self.title = title
        self.details = details
        self.dueAt = dueAt
        self.isDone = false
        self.reminderMinutes = reminderMinutes
        self.sourceText = sourceText
        self.createdAt = .now
        self.repeatKind = repeatKind
        self.repeatWeekdays = repeatWeekdays
        self.repeatInterval = repeatInterval
        self.startDate = startDate
        self.doneDates = []
    }
}

@Model
final class InboxNote {
    var id: UUID
    var content: String
    var source: String
    var createdAt: Date
    var isProcessed: Bool

    init(content: String, source: String) {
        self.id = UUID()
        self.content = content
        self.source = source
        self.createdAt = .now
        self.isProcessed = false
    }
}

/// 本地课程 ↔ 学习通课程的绑定。只保存完整课程链接（含会话 enc），不保存账号。
@Model
final class ChaoxingBinding {
    var localTitle: String
    var localTeacher: String
    var chaoxingName: String
    var courseURL: String = ""
    var updatedAt: Date

    init(
        localTitle: String,
        localTeacher: String = "",
        chaoxingName: String,
        courseURL: String = ""
    ) {
        self.localTitle = localTitle
        self.localTeacher = localTeacher
        self.chaoxingName = chaoxingName
        self.courseURL = courseURL
        self.updatedAt = .now
    }

    static func key(title: String, teacher: String) -> String {
        "\(title)|\(teacher)"
    }

    var key: String { Self.key(title: localTitle, teacher: localTeacher) }
}

enum TermClock {
    static let weekdays = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]

    static func monday(of date: Date) -> Date {
        var calendar = Calendar(identifier: .gregorian)
        calendar.firstWeekday = 2
        let start = calendar.startOfDay(for: date)
        let weekday = calendar.component(.weekday, from: start)
        let daysBack = (weekday + 5) % 7
        return calendar.date(byAdding: .day, value: -daysBack, to: start) ?? start
    }

    static func date(inWeekOf anchor: Date, weekday: Int) -> Date {
        Calendar.current.date(byAdding: .day, value: weekday - 1, to: monday(of: anchor)) ?? anchor
    }

    static func weekday(of date: Date) -> Int {
        (Calendar.current.component(.weekday, from: date) + 5) % 7 + 1
    }

    static func weekNumber(on date: Date, termStart: Date) -> Int {
        let days = Calendar.current.dateComponents([.day], from: monday(of: termStart), to: Calendar.current.startOfDay(for: date)).day ?? 0
        return days < 0 ? 0 : days / 7 + 1
    }

    static func occurs(_ course: CampusCourse, on date: Date, termStart: Date) -> Bool {
        let week = weekNumber(on: date, termStart: termStart)
        guard course.weekday == weekday(of: date) else { return false }
        // 有精确周次列表时优先用它（教务系统的 4,14 这种不连续周）
        if !course.weekList.isEmpty {
            return course.weekList.contains(week)
        }
        guard (course.firstWeek...course.lastWeek).contains(week) else { return false }
        return course.weekMode == 0 || (course.weekMode == 1 && week % 2 == 1) || (course.weekMode == 2 && week % 2 == 0)
    }

    static func time(_ minute: Int) -> String {
        String(format: "%02d:%02d", minute / 60, minute % 60)
    }

    static func dateTime(on date: Date, minute: Int) -> Date {
        Calendar.current.date(byAdding: .minute, value: minute, to: Calendar.current.startOfDay(for: date)) ?? date
    }
}
