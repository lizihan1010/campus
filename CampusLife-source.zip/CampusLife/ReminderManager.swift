import Foundation
import SwiftData
import UserNotifications

@MainActor
enum ReminderManager {
    static func rebuildFrom(context: ModelContext, termStart: Date) async {
        let courses = (try? context.fetch(FetchDescriptor<CampusCourse>())) ?? []
        let tasks = (try? context.fetch(FetchDescriptor<CampusTask>())) ?? []
        await rebuild(termStart: termStart, courses: courses, tasks: tasks)
        // 每次重排通知时，顺便把灵动岛刷新到当前该显示的那一节课
        LiveActivityManager.refresh(courses: courses, termStart: termStart)
    }

    static func requestPermission() async -> Bool {
        (try? await UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound])) ?? false
    }

    static func rebuild(termStart: Date, courses: [CampusCourse], tasks: [CampusTask]) async {
        let center = UNUserNotificationCenter.current()
        let settings = await center.notificationSettings()
        guard settings.authorizationStatus == .authorized || settings.authorizationStatus == .provisional else { return }

        let pending = await center.pendingNotificationRequests()
        center.removePendingNotificationRequests(withIdentifiers: pending.map(\.identifier).filter { $0.hasPrefix("campus.") })

        struct Candidate {
            let id: String
            let title: String
            let body: String
            let date: Date
        }

        let now = Date()
        let calendar = Calendar.current
        var candidates: [Candidate] = []

        // 自定义待办：一次 / 每周星期几 / 每隔 N 天，逐个执行日排提醒
        for task in tasks where task.hasTime && task.reminderMinutes >= 0 {
            for occurrence in TaskSchedule.occurrences(task, from: now, days: TaskSchedule.horizonDays) {
                let fire = occurrence.addingTimeInterval(TimeInterval(-max(task.reminderMinutes, 0) * 60))
                guard fire > now else { continue }
                let stamp = TaskSchedule.dayKey(occurrence) + String(format: "-%02d%02d",
                    calendar.component(.hour, from: occurrence), calendar.component(.minute, from: occurrence))
                let timeText = TermClock.time(calendar.component(.hour, from: occurrence) * 60 + calendar.component(.minute, from: occurrence))
                let detail = task.details.isEmpty ? TaskSchedule.summary(task) : "\(TaskSchedule.summary(task)) · \(task.details)"
                candidates.append(Candidate(
                    id: "campus.task.\(task.id).\(stamp)",
                    title: "待办提醒：\(task.title)",
                    body: "\(timeText) 该做的事 · \(detail)",
                    date: fire
                ))
            }
        }

        // 每堂课按全局设置（或该课单独设置）提前 N 分钟提醒，标题带课程名
        for offset in 0..<TaskSchedule.horizonDays {
            guard let day = calendar.date(byAdding: .day, value: offset, to: calendar.startOfDay(for: now)) else { continue }
            for course in courses where TermClock.occurs(course, on: day, termStart: termStart) {
                guard let minutes = ClassReminder.offset(for: course) else { continue }
                let fire = TermClock.dateTime(on: day, minute: course.startMinute).addingTimeInterval(TimeInterval(-minutes * 60))
                guard fire > now else { continue }
                let location = course.location.isEmpty ? "教室未填写" : course.location
                let teacher = course.teacher.isEmpty ? "" : " · \(course.teacher) 老师"
                candidates.append(Candidate(
                    id: "campus.course.\(course.id).\(TaskSchedule.dayKey(day))",
                    title: "\(minutes) 分钟后上课：\(course.title)",
                    body: "\(TermClock.time(course.startMinute))–\(TermClock.time(course.endMinute)) · \(location)\(teacher)",
                    date: fire
                ))
            }
        }

        for item in candidates.sorted(by: { $0.date < $1.date }).prefix(50) {
            let content = UNMutableNotificationContent()
            content.title = item.title
            content.body = item.body
            content.sound = .default
            let components = calendar.dateComponents([.year, .month, .day, .hour, .minute], from: item.date)
            let request = UNNotificationRequest(identifier: item.id, content: content, trigger: UNCalendarNotificationTrigger(dateMatching: components, repeats: false))
            try? await center.add(request)
        }
    }
}
