import Foundation
import SwiftData
import UserNotifications

@MainActor
enum ReminderManager {
    @MainActor
    static func rebuildFrom(context: ModelContext, termStart: Date) async {
        let courses = (try? context.fetch(FetchDescriptor<CampusCourse>())) ?? []
        let tasks = (try? context.fetch(FetchDescriptor<CampusTask>())) ?? []
        await rebuild(termStart: termStart, courses: courses, tasks: tasks)
    }

    static func requestPermission() async -> Bool {
        (try? await UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound])) ?? false
    }

    static func rebuild(termStart: Date, courses: [CampusCourse], tasks: [CampusTask]) async {
        let center = UNUserNotificationCenter.current()
        let settings = await center.notificationSettings()
        guard settings.authorizationStatus == .authorized || settings.authorizationStatus == .provisional else { return }

        let pending = await center.pendingNotificationRequests()
        center.removePendingNotificationRequests(withIdentifiers: pending.map(\.identifier).filter { $0.hasPrefix("campus.") })

        struct Candidate {
            let id: String
            let title: String
            let body: String
            let date: Date
        }

        let now = Date()
        var candidates: [Candidate] = []
        for task in tasks where !task.isDone && task.reminderMinutes >= 0 {
            let fire = task.dueAt.addingTimeInterval(TimeInterval(-max(task.reminderMinutes, 0) * 60))
            if fire > now {
                candidates.append(Candidate(id: "campus.task.\(task.id)", title: "待办提醒：\(task.title)", body: "截止时间即将到来", date: fire))
            }
        }

        for offset in 0..<14 {
            guard let day = Calendar.current.date(byAdding: .day, value: offset, to: Calendar.current.startOfDay(for: now)) else { continue }
            for course in courses where TermClock.occurs(course, on: day, termStart: termStart) {
                let fire = TermClock.dateTime(on: day, minute: course.startMinute).addingTimeInterval(-15 * 60)
                if fire > now {
                    let dayKey = ISO8601DateFormatter().string(from: day).prefix(10)
                    candidates.append(Candidate(id: "campus.course.\(course.id).\(dayKey)", title: "15 分钟后上课：\(course.title)", body: course.location.isEmpty ? "准备上课" : "教室：\(course.location)", date: fire))
                }
            }
        }

        for item in candidates.sorted(by: { $0.date < $1.date }).prefix(50) {
            let content = UNMutableNotificationContent()
            content.title = item.title
            content.body = item.body
            content.sound = .default
            let components = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: item.date)
            let request = UNNotificationRequest(identifier: item.id, content: content, trigger: UNCalendarNotificationTrigger(dateMatching: components, repeats: false))
            try? await center.add(request)
        }
    }
}
