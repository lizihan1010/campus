import Foundation
import SwiftData

/// 从教务系统解析出来的一门课（还没写进数据库）
struct ParsedCourse: Hashable {
    var title: String
    var teacher: String
    var location: String
    var weekday: Int        // 1 = 周一 … 7 = 周日
    var startMinute: Int
    var endMinute: Int
    var weeks: [Int]        // 具体周次，例如 [4,5,...,14] 或 [4,14]

    /// 用来和数据库里的旧记录比对：改教室/老师不算换课，改周次算换课
    var externalKey: String {
        let w = weeks.map(String.init).joined(separator: ",")
        return "\(title)|\(teacher)|\(w)"
    }
}

/// 节次 → 上下课时间（分钟）。按学校官方作息表填写。
enum PeriodTable {
    static let times: [Int: (start: Int, end: Int)] = [
        1:  (8 * 60,       8 * 60 + 45),
        2:  (8 * 60 + 50,  9 * 60 + 35),
        3:  (9 * 60 + 55,  10 * 60 + 40),
        4:  (10 * 60 + 45, 11 * 60 + 30),
        5:  (11 * 60 + 35, 12 * 60 + 20),
        6:  (14 * 60,      14 * 60 + 45),
        7:  (14 * 60 + 50, 15 * 60 + 35),
        8:  (15 * 60 + 55, 16 * 60 + 40),
        9:  (16 * 60 + 45, 17 * 60 + 30),
        10: (18 * 60 + 40, 19 * 60 + 25),
        11: (19 * 60 + 30, 20 * 60 + 15),
        12: (20 * 60 + 20, 21 * 60 + 5)
    ]

    static func start(_ period: Int) -> Int { times[period]?.start ?? 8 * 60 }
    static func end(_ period: Int) -> Int { times[period]?.end ?? (8 * 60 + 45) }

    /// 传入 [3,4,5]，返回第 3 节开始到第 5 节结束
    static func range(_ periods: [Int]) -> (start: Int, end: Int) {
        guard let first = periods.min(), let last = periods.max() else { return (8 * 60, 8 * 60 + 45) }
        return (start(first), end(last))
    }
}

/// 全量镜像同步：教务系统有什么，App 里就有什么（手动添加的课永远不动）
enum TimetableSync {

    struct Plan {
        var added: [ParsedCourse] = []
        var updated: [String: ParsedCourse] = [:]
        var removed: [CampusCourse] = []
        var unchanged: Int = 0

        var isEmpty: Bool { added.isEmpty && updated.isEmpty && removed.isEmpty }

        var summary: String {
            "新增 \(added.count) 门 · 修改 \(updated.count) 门 · 移除 \(removed.count) 门"
        }
    }

    // MARK: - 比对

    static func plan(parsed: [ParsedCourse], existing: [CampusCourse]) -> Plan {
        var result = Plan()

        var remote: [String: ParsedCourse] = [:]
        for item in parsed {
            if remote[item.externalKey] == nil { remote[item.externalKey] = item }
        }

        var local: [String: CampusCourse] = [:]
        for course in existing where course.source == "jxufe" {
            if local[course.externalKey] == nil { local[course.externalKey] = course }
        }

        for (key, item) in remote {
            if let old = local[key] {
                if needsUpdate(old, item) {
                    result.updated[key] = item
                } else {
                    result.unchanged += 1
                }
            } else {
                result.added.append(item)
            }
        }

        for (key, course) in local where remote[key] == nil {
            result.removed.append(course)
        }

        return result
    }

    private static func needsUpdate(_ old: CampusCourse, _ new: ParsedCourse) -> Bool {
        old.title != new.title ||
        old.teacher != new.teacher ||
        old.location != new.location ||
        old.weekday != new.weekday ||
        old.startMinute != new.startMinute ||
        old.endMinute != new.endMinute ||
        Set(old.weekList) != Set(new.weeks)
    }

    // MARK: - 应用

    @MainActor
    static func apply(_ plan: Plan, context: ModelContext) throws {
        for course in plan.removed {
            context.delete(course)
        }

        for (key, item) in plan.updated {
            let all = (try? context.fetch(FetchDescriptor<CampusCourse>())) ?? []
            guard let old = all.first(where: { $0.source == "jxufe" && $0.externalKey == key }) else { continue }
            old.title = item.title
            old.teacher = item.teacher
            old.location = item.location
            old.weekday = item.weekday
            old.startMinute = item.startMinute
            old.endMinute = item.endMinute
            old.firstWeek = item.weeks.min() ?? 1
            old.lastWeek = item.weeks.max() ?? 20
            old.weekList = item.weeks
        }

        for item in plan.added {
            context.insert(course(from: item))
        }

        try context.save()
    }

    static func course(from item: ParsedCourse) -> CampusCourse {
        CampusCourse(
            title: item.title,
            location: item.location,
            teacher: item.teacher,
            weekday: item.weekday,
            startMinute: item.startMinute,
            endMinute: item.endMinute,
            firstWeek: item.weeks.min() ?? 1,
            lastWeek: item.weeks.max() ?? 20,
            weekMode: 0,
            source: "jxufe",
            externalKey: item.externalKey,
            weekList: item.weeks
        )
    }

    // MARK: - 文本解析工具

    /// "3-5" → [3,4,5]；"1,3" → [1,3]；"1" → [1]
    static func periods(from text: String) -> [Int] {
        var result: [Int] = []
        for chunk in text.split(separator: ",") {
            let part = String(chunk).trimmingCharacters(in: .whitespaces)
            if let dash = part.firstIndex(of: "-") {
                let lower = Int(part[part.startIndex..<dash].trimmingCharacters(in: .whitespaces)) ?? 0
                let upper = Int(part[part.index(after: dash)...].trimmingCharacters(in: .whitespaces)) ?? 0
                if lower > 0 && upper >= lower {
                    result.append(contentsOf: Array(lower...upper))
                }
            } else if let single = Int(part), single > 0 {
                result.append(single)
            }
        }
        return Array(Set(result)).sorted()
    }

    /// "4-14" → 4…14；"4,14" → [4,14]；"1-16(单)" → 单周
    static func weeks(from text: String) -> [Int] {
        var odd = false
        var even = false
        var body = text
        if body.contains("单") { odd = true; body = body.replacingOccurrences(of: "(单)", with: "") }
        if body.contains("双") { even = true; body = body.replacingOccurrences(of: "(双)", with: "") }

        var result: [Int] = []
        for chunk in body.split(separator: ",") {
            let part = String(chunk).trimmingCharacters(in: .whitespaces)
            if let dash = part.firstIndex(of: "-") {
                let lower = Int(part[part.startIndex..<dash].trimmingCharacters(in: .whitespaces)) ?? 0
                let upper = Int(part[part.index(after: dash)...].trimmingCharacters(in: .whitespaces)) ?? 0
                if lower > 0 && upper >= lower { result.append(contentsOf: Array(lower...upper)) }
            } else if let single = Int(part), single > 0 {
                result.append(single)
            }
        }

        if odd { result = result.filter { $0 % 2 == 1 } }
        if even { result = result.filter { $0 % 2 == 0 } }
        return Array(Set(result)).sorted()
    }
}
