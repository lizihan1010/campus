import SwiftData

enum BundledSchedule2026Fall {
    @MainActor
    static func install(into context: ModelContext) throws {
        let existing = try context.fetch(FetchDescriptor<CampusCourse>())
        let bundled: [CampusCourse] = [
            CampusCourse(title: "大学生心理健康教育", location: "麦三教3106（麦庐园校区）", teacher: "谭弘", weekday: 5, startMinute: 840, endMinute: 935, firstWeek: 4, lastWeek: 11, weekMode: 0, note: "依据本学期课表录入", source: "bundled"),
            CampusCourse(title: "大学英语Ⅰ", location: "麦三教2205（麦庐园校区）", teacher: "吴春英", weekday: 5, startMinute: 595, endMinute: 740, firstWeek: 4, lastWeek: 14, weekMode: 0, note: "依据本学期课表录入", source: "bundled"),
            CampusCourse(title: "高等数学Ⅰ", location: "麦三教2209（麦庐园校区）", teacher: "余欢欢", weekday: 1, startMinute: 595, endMinute: 740, firstWeek: 4, lastWeek: 14, weekMode: 0, note: "依据本学期课表录入", source: "bundled"),
            CampusCourse(title: "高等数学Ⅰ", location: "麦三教2407（麦庐园校区）", teacher: "余欢欢", weekday: 3, startMinute: 595, endMinute: 740, firstWeek: 4, lastWeek: 14, weekMode: 0, note: "依据本学期课表录入", source: "bundled"),
            CampusCourse(title: "体育1", location: "麦足球场T051（麦庐园校区）", teacher: "李鑫尧", weekday: 4, startMinute: 840, endMinute: 935, firstWeek: 4, lastWeek: 15, weekMode: 0, note: "依据本学期课表录入", source: "bundled"),
            CampusCourse(title: "形势与政策Ⅰ", location: "麦三教3304（麦庐园校区）", teacher: "黄映琼", weekday: 3, startMinute: 955, endMinute: 1050, firstWeek: 13, lastWeek: 16, weekMode: 0, note: "依据本学期课表录入", source: "bundled"),
            CampusCourse(title: "习近平新时代中国特色社会主义思想概论", location: "麦三教3106（麦庐园校区）", teacher: "高尚", weekday: 1, startMinute: 955, endMinute: 1050, firstWeek: 4, lastWeek: 15, weekMode: 0, note: "依据本学期课表录入", source: "bundled"),
            CampusCourse(title: "习近平新时代中国特色社会主义思想概论", location: "麦三教3404（麦庐园校区）", teacher: "高尚", weekday: 2, startMinute: 840, endMinute: 935, firstWeek: 4, lastWeek: 15, weekMode: 0, note: "依据本学期课表录入", source: "bundled"),
            CampusCourse(title: "思想道德与法治", location: "麦三教2108（麦庐园校区）", teacher: "彭锦屏", weekday: 2, startMinute: 595, endMinute: 690, firstWeek: 4, lastWeek: 13, weekMode: 0, note: "依据本学期课表录入", source: "bundled"),
            CampusCourse(title: "思想道德与法治", location: "麦三教3401（麦庐园校区）", teacher: "彭锦屏", weekday: 4, startMinute: 595, endMinute: 690, firstWeek: 4, lastWeek: 13, weekMode: 0, note: "依据本学期课表录入", source: "bundled"),
            CampusCourse(title: "程序设计基础", location: "麦一教1503（麦庐园校区）", teacher: "骆斯文", weekday: 2, startMinute: 480, endMinute: 575, firstWeek: 4, lastWeek: 14, weekMode: 0, note: "依据本学期课表录入", source: "bundled"),
            CampusCourse(title: "程序设计基础", location: "麦一教1502（麦庐园校区）", teacher: "骆斯文", weekday: 4, startMinute: 955, endMinute: 1050, firstWeek: 4, lastWeek: 14, weekMode: 0, note: "依据本学期课表录入", source: "bundled"),
            CampusCourse(title: "程序设计基础", location: "数字经济实训大楼S401（麦庐园校区）", teacher: "骆斯文", weekday: 5, startMinute: 955, endMinute: 1050, firstWeek: 4, lastWeek: 14, weekMode: 0, note: "依据本学期课表录入", source: "bundled"),
            CampusCourse(title: "网络空间安全导论", location: "麦一教1405（麦庐园校区）", teacher: "赵若宇", weekday: 2, startMinute: 1120, endMinute: 1265, firstWeek: 4, lastWeek: 14, weekMode: 0, note: "依据本学期课表录入", source: "bundled"),
        ]
        for course in bundled {
            let alreadyPresent = existing.contains { old in
                old.title == course.title && old.weekday == course.weekday &&
                old.startMinute == course.startMinute && old.endMinute == course.endMinute &&
                old.firstWeek == course.firstWeek && old.lastWeek == course.lastWeek
            }
            if !alreadyPresent { context.insert(course) }
        }
        try context.save()
    }
}
