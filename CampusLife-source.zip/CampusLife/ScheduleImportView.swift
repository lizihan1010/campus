import PhotosUI
import SwiftUI

struct ScheduleImportView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var selectedPhoto: PhotosPickerItem?
    @State private var recognizedText = ""
    @State private var busy = false
    @State private var errorText: String?
    @State private var showCourseEditor = false

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Text("选择喜鹊儿课表截图。识别出的文字供你核对课程名、教室和节次；每门课程仍需确认星期和时间。")
                        .font(.subheadline).foregroundStyle(.secondary)
                    PhotosPicker(selection: $selectedPhoto, matching: .images) {
                        Label(busy ? "正在识别" : "选择课表截图", systemImage: "photo")
                    }
                    .disabled(busy)
                    if let errorText { Text(errorText).font(.footnote).foregroundStyle(.red) }
                }
                if !recognizedText.isEmpty {
                    Section("识别结果，可修改") {
                        TextEditor(text: $recognizedText).frame(minHeight: 220)
                        Button("根据内容添加一门课") { showCourseEditor = true }
                            .buttonStyle(.borderedProminent)
                    }
                }
            }
            .navigationTitle("导入课表")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("完成") { dismiss() } } }
            .sheet(isPresented: $showCourseEditor) { CourseEditor(initialNote: String(recognizedText.prefix(500))) }
            .onChange(of: selectedPhoto) { _, newPhoto in
                guard let newPhoto else { return }
                Task { await recognize(newPhoto) }
            }
        }
    }

    private func recognize(_ item: PhotosPickerItem) async {
        busy = true
        defer { busy = false; selectedPhoto = nil }
        do {
            guard let data = try await item.loadTransferable(type: Data.self), data.count <= 20_000_000 else {
                errorText = "无法读取图片，或图片超过 20 MB"
                return
            }
            recognizedText = try await OCRService.text(from: data)
            errorText = recognizedText.isEmpty ? "没有识别到文字，请尝试更清晰的截图" : nil
        } catch {
            errorText = "识别失败，请换一张截图重试"
        }
    }
}
