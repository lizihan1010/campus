import SwiftData
import SwiftUI

/// 课表界面按应要求恢复到精简改版之前的样式：
/// 顶部周切换 + 横向 7 列大卡片（时间区间 / 教室 / 学习通标识）+ 长按菜单。
/// 只把已失效的「识别课表截图」换成「从教务系统同步」，点卡片仍进课程详情。
struct ScheduleView: View {
    @Query private var courses: [CampusCourse]
    @Environment(\.modelContext) private var context
    @AppStorage("termStartTimestamp") private var termStartTimestamp = 0.0
    @State private var weekAnchor = Date.now
    @State private var showEditor = false
    @State private var showSync = false
    @State private var detailCourse: CourseBox?
    @State private var editingCourse: CourseBox?

    private var termStart: Date { Date(timeIntervalSince1970: termStartTimestamp) }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                HStack {
                    Button { moveWeek(-1) } label: { Image(systemName: "chevron.left").frame(width: 44, height: 44) }
                    Spacer()
                    VStack(spacing: 2) {
                        Text(weekAnchor.formatted(.dateTime.month().day()) + " 起").font(.headline)
                        Text(termStartTimestamp > 0 ? "第 \(TermClock.weekNumber(on: weekAnchor, termStart: termStart)) 周" : "学期未设置")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Button { moveWeek(1) } label: { Image(systemName: "chevron.right").frame(width: 44, height: 44) }
                }
                .padding(.horizontal, 12)

                if termStartTimestamp == 0 {
                    EmptyMessage(symbol: "calendar.badge.exclamationmark", title: "先设置学期", message: "在「我的」中填入第一周的周一。")
                }

                ScrollView(.horizontal) {
                    HStack(alignment: .top, spacing: 8) {
                        ForEach(1...7, id: \.self) { day in dayColumn(day) }
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                }
                Spacer(minLength: 0)
            }
            .background(CampusPalette.background)
            .navigationTitle("一周课表")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        Button("手动添加课程", systemImage: "plus") { showEditor = true }
                        Button("从教务系统同步", systemImage: "arrow.triangle.2.circlepath") { showSync = true }
                    } label: { Image(systemName: "plus") }
                    .accessibilityLabel("添加或同步课程")
                }
            }
            .sheet(isPresented: $showEditor) { CourseEditor() }
            .sheet(isPresented: $showSync) { SchoolSyncSheet() }
            .sheet(item: $detailCourse) { box in
                NavigationStack { CourseDetailView(course: box.course) }
            }
            .sheet(item: $editingCourse) { box in
                CourseEditor(course: box.course)
            }
        }
    }

    private func dayColumn(_ day: Int) -> some View {
        let date = TermClock.date(inWeekOf: weekAnchor, weekday: day)
        let visible = courses.filter { termStartTimestamp > 0 && TermClock.occurs($0, on: date, termStart: termStart) }
            .sorted { $0.startMinute < $1.startMinute }
        return VStack(alignment: .leading, spacing: 9) {
            VStack(alignment: .leading, spacing: 3) {
                Text(TermClock.weekdays[day - 1]).font(.subheadline.bold())
                Text(date.formatted(.dateTime.month().day())).font(.caption).foregroundStyle(.secondary)
            }
            .padding(.horizontal, 3)
            .frame(maxWidth: .infinity, alignment: .leading)

            ForEach(visible) { course in
                Button { detailCourse = CourseBox(course: course) } label: {
                    VStack(alignment: .leading, spacing: 8) {
                        Text(TermClock.time(course.startMinute) + "–" + TermClock.time(course.endMinute))
                            .font(.caption2.bold()).monospacedDigit().foregroundStyle(CampusPalette.primary)
                        Text(course.title).font(.subheadline.bold()).foregroundStyle(.primary).multilineTextAlignment(.leading)
                        if !course.location.isEmpty { Text(course.location).font(.caption2).foregroundStyle(.secondary) }
                        HStack(spacing: 3) {
                            Image(systemName: "arrow.up.right.square").font(.caption2)
                            Text("学习通").font(.caption2)
                        }
                        .foregroundStyle(.tertiary)
                    }
                    .padding(11)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(CampusPalette.card, in: RoundedRectangle(cornerRadius: 14))
                }
                .buttonStyle(.plain)
                .contextMenu {
                    Button("课程详情", systemImage: "info.circle") { detailCourse = CourseBox(course: course) }
                    Button("编辑课程", systemImage: "pencil") { editingCourse = CourseBox(course: course) }
                    Button("删除课程", systemImage: "trash", role: .destructive) { delete(course) }
                }
            }
            if visible.isEmpty {
                Text("无课")
                    .font(.caption).foregroundStyle(.tertiary)
                    .frame(maxWidth: .infinity, minHeight: 76)
                    .background(CampusPalette.card, in: RoundedRectangle(cornerRadius: 14))
            }
        }
        .frame(width: 134, alignment: .topLeading)
    }

    private func moveWeek(_ amount: Int) {
        weekAnchor = Calendar.current.date(byAdding: .weekOfYear, value: amount, to: weekAnchor) ?? weekAnchor
    }

    private func delete(_ course: CampusCourse) {
        context.delete(course)
        try? context.save()
        if termStartTimestamp > 0 {
            Task {
                await ReminderManager.rebuildFrom(
                    context: context,
                    termStart: Date(timeIntervalSince1970: termStartTimestamp)
                )
            }
        }
    }
}

/// 用 Identifiable 包装，方便用 sheet(item:) 弹出
struct CourseBox: Identifiable {
    let id: UUID
    let course: CampusCourse

    init(course: CampusCourse) {
        self.id = course.id
        self.course = course
    }
}

struct CourseDetailView: View {
    let course: CampusCourse
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @AppStorage("termStartTimestamp") private var termStartTimestamp = 0.0
    @Query private var bindings: [ChaoxingBinding]
    @State private var showEditor = false
    @State private var selectedService: CampusService?
    @State private var confirmDelete = false
    @State private var launchMessage: String?
    @State private var safariURL: URL?
    @State private var activityMessage: String?

    private var binding: ChaoxingBinding? {
        let key = ChaoxingBinding.key(title: course.title, teacher: course.teacher)
        return bindings.first { $0.key == key }
    }

    private var reminderText: String {
        guard let offset = ClassReminder.offset(for: course) else { return "这节课不提醒" }
        let scope = course.reminderOverride > 0 ? "单独设置" : "跟随全局"
        return "课前 \(offset) 分钟提醒 · \(scope)"
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                CampusCard {
                    VStack(alignment: .leading, spacing: 8) {
                        Text(course.title).font(.title3.bold())
                        Label("\(TermClock.weekdays[course.weekday - 1]) \(TermClock.time(course.startMinute))–\(TermClock.time(course.endMinute))", systemImage: "clock")
                            .font(.subheadline)
                        if !course.location.isEmpty { Label(course.location, systemImage: "mappin").font(.subheadline) }
                        if !course.teacher.isEmpty { Label(course.teacher, systemImage: "person").font(.subheadline) }
                        Text(weekText).font(.caption).foregroundStyle(.secondary)
                        Text(reminderText).font(.caption).foregroundStyle(CampusPalette.primary)
                        if !course.note.isEmpty { Text(course.note).font(.caption).foregroundStyle(.secondary) }
                    }
                }

                HStack(spacing: 10) {
                    Button { selectedService = .signIn } label: {
                        Label("扫码签到", systemImage: "qrcode.viewfinder")
                            .font(.subheadline.weight(.medium))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 10)
                            .background(CampusPalette.primary, in: RoundedRectangle(cornerRadius: 11, style: .continuous))
                            .foregroundStyle(.white)
                    }
                    .buttonStyle(.plain)

                    Button { openChaoxing() } label: {
                        Label("学习通", systemImage: "arrow.up.right.square")
                            .font(.subheadline.weight(.medium))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 10)
                            .background(CampusPalette.card, in: RoundedRectangle(cornerRadius: 11, style: .continuous))
                    }
                    .buttonStyle(.plain)
                }

                Button {
                    activityMessage = LiveActivityManager.show(course: course)
                } label: {
                    Label("在灵动岛显示这节课", systemImage: "capsule.fill")
                        .font(.subheadline.weight(.medium))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .background(CampusPalette.card, in: RoundedRectangle(cornerRadius: 11, style: .continuous))
                }
                .buttonStyle(.plain)

                if let activityMessage {
                    Text(activityMessage).font(.caption).foregroundStyle(.secondary)
                }
                Text("打开入口不代表已完成签到，结果请在原服务核对。可在「编辑课程」里单独设置这节课的提醒提前量。")
                    .font(.caption).foregroundStyle(.secondary)
            }
            .padding(16)
        }
        .background(CampusPalette.background)
        .navigationTitle("课程详情")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    Button("编辑课程", systemImage: "pencil") { showEditor = true }
                    Button("删除课程", systemImage: "trash", role: .destructive) { confirmDelete = true }
                } label: { Image(systemName: "ellipsis.circle") }
            }
        }
        .sheet(isPresented: $showEditor) { CourseEditor(course: course) }
        .sheet(item: $selectedService) { ServiceSheet(service: $0) }
        .sheet(isPresented: Binding(get: { safariURL != nil }, set: { if !$0 { safariURL = nil } })) {
            if let safariURL { SafariView(url: safariURL).ignoresSafeArea() }
        }
        .confirmationDialog("删除这门课程？", isPresented: $confirmDelete) {
            Button("删除", role: .destructive) { deleteCourse() }
        }
        .alert("无法打开", isPresented: Binding(get: { launchMessage != nil }, set: { if !$0 { launchMessage = nil } })) {
            Button("好") { launchMessage = nil }
        } message: {
            Text(launchMessage ?? "")
        }
    }

    private var weekText: String {
        if !course.weekList.isEmpty {
            return "第 \(course.weekList.map(String.init).joined(separator: ",")) 周"
        }
        return "第 \(course.firstWeek)–\(course.lastWeek) 周 · \(["每周", "单周", "双周"][max(0, min(2, course.weekMode))])"
    }

    /// 已绑定课程链接就直接打开；没有绑定时只启动学习通 App。
    private func openChaoxing() {
        if let link = binding?.courseURL, !link.isEmpty, let url = URL(string: link) {
            safariURL = url
            return
        }
        Task {
            let opened = await ExternalRoutes.runShortcut("校园-学习通")
            if !opened { launchMessage = "无法打开「校园-学习通」快捷指令，请到「我的 → 服务入口」核对名称。" }
        }
    }

    private func deleteCourse() {
        context.delete(course)
        try? context.save()
        if termStartTimestamp > 0 {
            Task { await ReminderManager.rebuildFrom(context: context, termStart: Date(timeIntervalSince1970: termStartTimestamp)) }
        }
        dismiss()
    }
}
