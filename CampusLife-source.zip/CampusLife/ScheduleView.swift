import SwiftData
import SwiftUI

struct ScheduleView: View {
    @Query private var courses: [CampusCourse]
    @AppStorage("termStartTimestamp") private var termStartTimestamp = 0.0
    @State private var weekAnchor = Date.now
    @State private var showEditor = false
    @State private var showImport = false

    private var termStart: Date { Date(timeIntervalSince1970: termStartTimestamp) }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                HStack {
                    Button { moveWeek(-1) } label: { Image(systemName: "chevron.left").frame(width: 44, height: 44) }
                    Spacer()
                    VStack(spacing: 2) {
                        Text(weekAnchor.formatted(.dateTime.month().day()) + " 起").font(.headline)
                        Text(termStartTimestamp > 0 ? "第 \(TermClock.weekNumber(on: weekAnchor, termStart: termStart)) 周" : "学期未设置")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Button { moveWeek(1) } label: { Image(systemName: "chevron.right").frame(width: 44, height: 44) }
                }
                .padding(.horizontal, 12)

                if termStartTimestamp == 0 {
                    EmptyMessage(symbol: "calendar.badge.exclamationmark", title: "先设置学期", message: "在“我的”中填入第一周的周一。")
                }

                ScrollView(.horizontal) {
                    HStack(alignment: .top, spacing: 8) {
                        ForEach(1...7, id: \.self) { day in dayColumn(day) }
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                }
                Spacer(minLength: 0)
            }
            .background(CampusPalette.background)
            .navigationTitle("一周课表")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        Button("手动添加课程", systemImage: "plus") { showEditor = true }
                        Button("识别课表截图", systemImage: "text.viewfinder") { showImport = true }
                    } label: { Image(systemName: "plus") }
                    .accessibilityLabel("添加或导入课程")
                }
            }
            .sheet(isPresented: $showEditor) { CourseEditor() }
            .sheet(isPresented: $showImport) { ScheduleImportView() }
        }
    }

    private func dayColumn(_ day: Int) -> some View {
        let date = TermClock.date(inWeekOf: weekAnchor, weekday: day)
        let visible = courses.filter { termStartTimestamp > 0 && TermClock.occurs($0, on: date, termStart: termStart) }.sorted { $0.startMinute < $1.startMinute }
        return VStack(alignment: .leading, spacing: 9) {
            VStack(alignment: .leading, spacing: 3) {
                Text(TermClock.weekdays[day - 1]).font(.subheadline.bold())
                Text(date.formatted(.dateTime.month().day())).font(.caption).foregroundStyle(.secondary)
            }
            .padding(.horizontal, 3)
            .frame(maxWidth: .infinity, alignment: .leading)

            ForEach(visible) { course in
                NavigationLink { CourseDetailView(course: course) } label: {
                    VStack(alignment: .leading, spacing: 8) {
                        Text(TermClock.time(course.startMinute) + "–" + TermClock.time(course.endMinute))
                            .font(.caption2.bold()).monospacedDigit().foregroundStyle(CampusPalette.primary)
                        Text(course.title).font(.subheadline.bold()).foregroundStyle(.primary).multilineTextAlignment(.leading)
                        if !course.location.isEmpty { Text(course.location).font(.caption2).foregroundStyle(.secondary) }
                    }
                    .padding(11)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(CampusPalette.card, in: RoundedRectangle(cornerRadius: 14))
                }
                .buttonStyle(.plain)
            }
            if visible.isEmpty {
                Text("无课")
                    .font(.caption).foregroundStyle(.tertiary)
                    .frame(maxWidth: .infinity, minHeight: 76)
                    .background(CampusPalette.card, in: RoundedRectangle(cornerRadius: 14))
            }
        }
        .frame(width: 134, alignment: .topLeading)
    }

    private func moveWeek(_ amount: Int) {
        weekAnchor = Calendar.current.date(byAdding: .weekOfYear, value: amount, to: weekAnchor) ?? weekAnchor
    }
}

struct CourseDetailView: View {
    let course: CampusCourse
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @AppStorage("termStartTimestamp") private var termStartTimestamp = 0.0
    @State private var showEditor = false
    @State private var selectedService: CampusService?
    @State private var confirmDelete = false
    @State private var launchMessage: String?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                CampusCard {
                    VStack(alignment: .leading, spacing: 10) {
                        Text(course.title).font(.title2.bold())
                        Label("\(TermClock.weekdays[course.weekday - 1]) \(TermClock.time(course.startMinute))–\(TermClock.time(course.endMinute))", systemImage: "clock")
                        if !course.location.isEmpty { Label(course.location, systemImage: "mappin") }
                        if !course.teacher.isEmpty { Label(course.teacher, systemImage: "person") }
                        Text("第 \(course.firstWeek)–\(course.lastWeek) 周 · \(["每周", "单周", "双周"][max(0, min(2, course.weekMode))])")
                            .font(.subheadline).foregroundStyle(.secondary)
                        if !course.note.isEmpty { Text(course.note).font(.subheadline) }
                    }
                }
                Button { selectedService = .signIn } label: {
                    Label("修猫助手扫码签到", systemImage: "qrcode.viewfinder")
                        .frame(maxWidth: .infinity).padding(.vertical, 8)
                }
                .buttonStyle(.borderedProminent)

                Button {
                    Task {
                        let opened = await ExternalRoutes.runShortcut("校园-学习通")
                        if !opened { launchMessage = "无法打开快捷指令。请到“我的”核对名称和对应 App。" }
                    }
                } label: {
                    Label("打开学习通", systemImage: "arrow.up.right.square")
                        .frame(maxWidth: .infinity).padding(.vertical, 8)
                }
                .buttonStyle(.bordered)
                Text("打开入口不代表已完成签到。签到结果请在原服务中核对。")
                    .font(.footnote).foregroundStyle(.secondary)

                Button("编辑课程") { showEditor = true }
                Button("删除课程", role: .destructive) { confirmDelete = true }
            }
            .padding(20)
        }
        .background(CampusPalette.background)
        .navigationTitle("课程详情")
        .navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $showEditor) { CourseEditor(course: course) }
        .sheet(item: $selectedService) { ServiceSheet(service: $0) }
        .confirmationDialog("删除这门课程？", isPresented: $confirmDelete) {
            Button("删除", role: .destructive) { deleteCourse() }
        }
        .alert("无法打开", isPresented: Binding(get: { launchMessage != nil }, set: { if !$0 { launchMessage = nil } })) {
            Button("好") { launchMessage = nil }
        } message: {
            Text(launchMessage ?? "")
        }
    }

    private func deleteCourse() {
        context.delete(course)
        try? context.save()
        if termStartTimestamp > 0 {
            Task { await ReminderManager.rebuildFrom(context: context, termStart: Date(timeIntervalSince1970: termStartTimestamp)) }
        }
        dismiss()
    }
}
