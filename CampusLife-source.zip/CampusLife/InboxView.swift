import PhotosUI
import SwiftData
import SwiftUI
import UIKit
import Vision

struct InboxView: View {
    @Query(sort: \InboxNote.createdAt, order: .reverse) private var notes: [InboxNote]
    @Environment(\.modelContext) private var context
    @State private var draft = ""
    @State private var selectedPhoto: PhotosPickerItem?
    @State private var source = "手动输入"
    @State private var busy = false
    @State private var errorText: String?
    @State private var taskSource: InboxNote?

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    CampusCard {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("收集一条通知").font(.headline)
                            Text("粘贴群消息，或选一张截图识别。保存前可以检查和修改文字。")
                                .font(.subheadline).foregroundStyle(.secondary)
                            TextEditor(text: $draft)
                                .scrollContentBackground(.hidden)
                                .frame(minHeight: 125)
                                .padding(7)
                                .background(CampusPalette.background, in: RoundedRectangle(cornerRadius: 12))
                                .accessibilityLabel("通知内容")
                            HStack {
                                Button("粘贴") {
                                    if let text = UIPasteboard.general.string, !text.isEmpty {
                                        draft = String(text.prefix(10_000))
                                        source = "剪贴板"
                                        errorText = nil
                                    } else {
                                        errorText = "剪贴板里没有文字"
                                    }
                                }
                                .buttonStyle(.bordered)

                                PhotosPicker(selection: $selectedPhoto, matching: .images) {
                                    Label(busy ? "识别中" : "选截图", systemImage: "photo")
                                }
                                .buttonStyle(.bordered)
                                .disabled(busy)

                                Spacer()
                                Button("保存") { save() }
                                    .buttonStyle(.borderedProminent)
                                    .disabled(draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || busy)
                            }
                            if let errorText { Text(errorText).font(.footnote).foregroundStyle(.red) }
                        }
                    }

                    SectionHeader(title: "待整理", subtitle: "识别结果需人工确认")
                        .padding(.horizontal, -20)
                    if notes.isEmpty {
                        CampusCard { EmptyMessage(symbol: "tray", title: "还没有消息", message: "把 QQ 或微信里的通知复制到这里，或选择一张截图。") }
                    }
                    ForEach(notes) { note in
                        CampusCard {
                            VStack(alignment: .leading, spacing: 12) {
                                HStack {
                                    Text(note.source).font(.caption.bold()).foregroundStyle(CampusPalette.primary)
                                    Spacer()
                                    Text(note.createdAt, format: .dateTime.month().day().hour().minute())
                                        .font(.caption).foregroundStyle(.secondary)
                                }
                                Text(note.content).font(.subheadline).lineLimit(8)
                                HStack {
                                    Button("转为待办") { taskSource = note }
                                        .buttonStyle(.borderedProminent)
                                    Button(note.isProcessed ? "已处理" : "标记已处理") {
                                        note.isProcessed = true
                                        try? context.save()
                                    }
                                    .buttonStyle(.bordered)
                                    .disabled(note.isProcessed)
                                    Spacer()
                                    Button(role: .destructive) {
                                        context.delete(note)
                                        try? context.save()
                                    } label: { Image(systemName: "trash") }
                                    .accessibilityLabel("删除通知")
                                }
                            }
                        }
                        .opacity(note.isProcessed ? 0.65 : 1)
                    }
                }
                .padding(20)
            }
            .background(CampusPalette.background)
            .navigationTitle("收件箱")
            .sheet(item: $taskSource) { TaskEditor(sourceText: $0.content) }
            .onChange(of: selectedPhoto) { _, newPhoto in
                guard let newPhoto else { return }
                Task { await recognize(newPhoto) }
            }
        }
    }

    private func save() {
        let content = draft.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !content.isEmpty else { return }
        context.insert(InboxNote(content: content, source: source))
        do {
            try context.save()
            draft = ""
            source = "手动输入"
            errorText = nil
        } catch {
            errorText = "保存失败，请重试：\(error.localizedDescription)"
        }
    }

    private func recognize(_ item: PhotosPickerItem) async {
        busy = true
        defer { busy = false; selectedPhoto = nil }
        do {
            guard let data = try await item.loadTransferable(type: Data.self) else {
                errorText = "无法读取这张图片，请换一张截图"
                return
            }
            guard data.count <= 20_000_000 else {
                errorText = "图片过大，请选一张 20 MB 以内的截图"
                return
            }
            let result = try await OCRService.text(from: data)
            guard !result.isEmpty else {
                errorText = "截图中没有识别到文字，请手动输入"
                return
            }
            draft = result
            source = "截图识别"
            errorText = nil
        } catch {
            errorText = "识别失败，请重试：\(error.localizedDescription)"
        }
    }
}

enum OCRService {
    static func text(from data: Data) async throws -> String {
        try await Task.detached(priority: .userInitiated) {
            guard let image = UIImage(data: data)?.cgImage else { return "" }
            let request = VNRecognizeTextRequest()
            request.recognitionLevel = .accurate
            request.recognitionLanguages = ["zh-Hans", "en-US"]
            request.usesLanguageCorrection = true
            let handler = VNImageRequestHandler(cgImage: image, options: [:])
            try handler.perform([request])
            return (request.results ?? []).compactMap { $0.topCandidates(1).first?.string }.joined(separator: "\n")
        }.value
    }
}
