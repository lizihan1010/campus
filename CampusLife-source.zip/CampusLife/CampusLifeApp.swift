import SwiftData
import SwiftUI

@main
struct CampusLifeApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
        }
        .modelContainer(for: [CampusCourse.self, CampusTask.self, InboxNote.self])
    }
}

struct RootView: View {
    @AppStorage("termStartTimestamp") private var termStartTimestamp = 0.0
    @AppStorage("bundledSchedule2026FallVersion") private var bundledScheduleVersion = 0
    @Environment(\.modelContext) private var modelContext

    var body: some View {
        TabView {
            TodayView()
                .tabItem { Label("今天", systemImage: "sun.max.fill") }
            ScheduleView()
                .tabItem { Label("课表", systemImage: "calendar") }
            InboxView()
                .tabItem { Label("收件箱", systemImage: "tray.fill") }
            SettingsView()
                .tabItem { Label("我的", systemImage: "person.crop.circle") }
        }
        .tint(CampusPalette.primary)
        .task {
            if bundledScheduleVersion < 1 {
                do {
                    try BundledSchedule2026Fall.install(into: modelContext)
                    if let monday = Calendar.current.date(from: DateComponents(year: 2026, month: 9, day: 7)) {
                        termStartTimestamp = monday.timeIntervalSince1970
                    }
                    UserDefaults.standard.set("2026秋季学期", forKey: "termName")
                    bundledScheduleVersion = 1
                } catch {
                    // Keep the version unset so the import can be retried next launch.
                    print("Bundled schedule import failed: \(error)")
                }
            }
            if termStartTimestamp > 0 {
                await ReminderManager.rebuildFrom(context: modelContext, termStart: Date(timeIntervalSince1970: termStartTimestamp))
            }
        }
    }
}
