import SwiftData
import SwiftUI

@main
struct CampusLifeApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
        }
        .modelContainer(for: [CampusCourse.self, CampusTask.self, InboxNote.self, ChaoxingBinding.self])
    }
}

struct RootView: View {
    @AppStorage("termStartTimestamp") private var termStartTimestamp = 0.0
    @Environment(\.modelContext) private var modelContext
    @Environment(\.scenePhase) private var scenePhase

    var body: some View {
        TabView {
            TodayView()
                .tabItem { Label("今天", systemImage: "sun.max.fill") }
            ScheduleView()
                .tabItem { Label("课表", systemImage: "calendar") }
            InboxView()
                .tabItem { Label("收件箱", systemImage: "tray.fill") }
            SettingsView()
                .tabItem { Label("我的", systemImage: "person.crop.circle") }
        }
        .tint(CampusPalette.primary)
        .task { await refresh() }
        .onChange(of: scenePhase) { _, phase in
            // 回到前台时重排通知并刷新灵动岛；无推送服务器，只能靠前台刷新
            if phase == .active { Task { await refresh() } }
        }
    }

    private func refresh() async {
        guard termStartTimestamp > 0 else { return }
        await ReminderManager.rebuildFrom(
            context: modelContext,
            termStart: Date(timeIntervalSince1970: termStartTimestamp)
        )
    }
}
