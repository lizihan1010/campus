import SwiftData
import SwiftUI

@main
struct CampusLifeApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
        }
        .modelContainer(for: [CampusCourse.self, CampusTask.self, InboxNote.self, ChaoxingBinding.self])
    }
}

struct RootView: View {
    @AppStorage("termStartTimestamp") private var termStartTimestamp = 0.0
    @Environment(\.modelContext) private var modelContext
    @Environment(\.scenePhase) private var scenePhase

    var body: some View {
        TabView {
            TodayView()
                .tabItem { Label("今天", systemImage: "sun.max.fill") }
            ScheduleView()
                .tabItem { Label("课表", systemImage: "calendar") }
            InboxView()
                .tabItem { Label("收件箱", systemImage: "tray.fill") }
            SettingsView()
                .tabItem { Label("我的", systemImage: "person.crop.circle") }
        }
        .tint(CampusPalette.primary)
        .task(id: scenePhase) {
            // 前台每分钟检查课程边界；切到后台时此任务会取消。
            while scenePhase == .active && !Task.isCancelled {
                await refresh()
                try? await Task.sleep(for: .seconds(60))
            }
        }
    }

    private func refresh() async {
        guard termStartTimestamp > 0 else { return }
        await ReminderManager.rebuildFrom(
            context: modelContext,
            termStart: Date(timeIntervalSince1970: termStartTimestamp)
        )
    }
}
