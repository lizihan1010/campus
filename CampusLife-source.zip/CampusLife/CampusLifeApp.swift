import SwiftData
import SwiftUI

@main
struct CampusLifeApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
        }
        .modelContainer(for: [CampusCourse.self, CampusTask.self, InboxNote.self, ChaoxingBinding.self])
    }
}

struct RootView: View {
    @AppStorage("termStartTimestamp") private var termStartTimestamp = 0.0
    @Environment(\.modelContext) private var modelContext
    @Environment(\.scenePhase) private var scenePhase

    var body: some View {
        TabView {
            TodayView()
                .tabItem { Label("今天", systemImage: "sun.max.fill") }
            ScheduleView()
                .tabItem { Label("课表", systemImage: "calendar") }
            InboxView()
                .tabItem { Label("收件箱", systemImage: "tray.fill") }
            SettingsView()
                .tabItem { Label("我的", systemImage: "person.crop.circle") }
        }
        .tint(CampusPalette.primary)
        .task(id: scenePhase) {
            // 前台每分钟检查课程边界；切到后台时此任务会取消。
            while scenePhase == .active && !Task.isCancelled {
                await refresh()
                try? await Task.sleep(for: .seconds(60))
            }
        }
    }

    @MainActor
    private func refresh() async {
        do {
            try MorningReadingInstaller.installIfNeeded(into: modelContext)
        } catch {
            print("添加晨读课程失败：\(error.localizedDescription)")
        }
        guard termStartTimestamp > 0 else { return }
        await ReminderManager.rebuildFrom(
            context: modelContext,
            termStart: Date(timeIntervalSince1970: termStartTimestamp)
        )
    }
}

/// 升级旧安装时补入两条晨读；用户手动删除后不再自动恢复。
private enum MorningReadingInstaller {
    private static let installedKey = "morningReading2026FallInstalled"

    @MainActor
    static func installIfNeeded(into context: ModelContext) throws {
        guard !UserDefaults.standard.bool(forKey: installedKey) else { return }
        let existing = try context.fetch(FetchDescriptor<CampusCourse>())
        for (weekday, room) in [(2, "麦一教1207"), (4, "麦一教1413")] {
            guard !existing.contains(where: { $0.title == "晨读" && $0.weekday == weekday }) else { continue }
            context.insert(CampusCourse(
                title: "晨读",
                location: room,
                weekday: weekday,
                startMinute: 7 * 60 + 10,
                endMinute: 7 * 60 + 40,
                firstWeek: 1,
                lastWeek: 20,
                note: "每周晨读",
                source: "bundled",
                externalKey: "morning-reading-\(weekday)"
            ))
        }
        try context.save()
        UserDefaults.standard.set(true, forKey: installedKey)
    }
}
