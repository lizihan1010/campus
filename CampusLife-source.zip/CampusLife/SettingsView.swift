import SwiftData
import SwiftUI
import UIKit
import UniformTypeIdentifiers
import UserNotifications

struct SettingsView: View {
    @Environment(\.modelContext) private var context
    @AppStorage("termStartTimestamp") private var termStartTimestamp = 0.0
    @AppStorage("termName") private var termName = "本学期"
    @State private var notificationStatus = "尚未检查"
    @State private var exportURL: URL?
    @State private var isImporting = false
    @State private var backupMessage: String?
    @State private var showShowerManagement = false

    private var startBinding: Binding<Date> {
        Binding(
            get: { termStartTimestamp > 0 ? Date(timeIntervalSince1970: termStartTimestamp) : TermClock.monday(of: .now) },
            set: { newDate in
                termStartTimestamp = TermClock.monday(of: newDate).timeIntervalSince1970
                Task { await ReminderManager.rebuildFrom(context: context, termStart: Date(timeIntervalSince1970: termStartTimestamp)) }
            }
        )
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("学期名称", text: $termName)
                    DatePicker("第一周的周一", selection: startBinding, displayedComponents: .date)
                    if termStartTimestamp == 0 {
                        Text("尚未保存学期起始日期。请选择实际开学第一周中的任意一天，应用会自动归到周一。")
                            .font(.footnote).foregroundStyle(.secondary)
                        Button("先设为本周一") {
                            termStartTimestamp = TermClock.monday(of: .now).timeIntervalSince1970
                            Task { await ReminderManager.rebuildFrom(context: context, termStart: Date(timeIntervalSince1970: termStartTimestamp)) }
                        }
                    }
                } header: { Text("学期设置") } footer: { Text("课表周次与单双周以这里的日期为准。") }

                Section("提醒") {
                    HStack {
                        Text("通知权限")
                        Spacer()
                        Text(notificationStatus).foregroundStyle(.secondary)
                    }
                    Button("开启提醒并重新安排") {
                        Task {
                            let granted = await ReminderManager.requestPermission()
                            notificationStatus = granted ? "已开启" : "未开启"
                            if granted {
                                await ReminderManager.rebuildFrom(context: context, termStart: termStartTimestamp > 0 ? Date(timeIntervalSince1970: termStartTimestamp) : .now)
                            }
                        }
                    }
                    if notificationStatus == "已关闭" {
                        Button("去系统设置开启通知") {
                            if let url = URL(string: UIApplication.openSettingsURLString) {
                                Task { _ = await UIApplication.shared.open(url) }
                            }
                        }
                    }
                    Text("课程提前 15 分钟；待办按各自设置提醒。通知被关闭时，待办仍在首页显示。")
                        .font(.footnote).foregroundStyle(.secondary)
                }

                Section("快捷指令配置") {
                    Text("在 iPhone“快捷指令”里创建对应的“打开 App”操作，名称必须完全一致：")
                    Text("校园-喝水 → 慧生活798\n校园-课表 → 喜鹊儿")
                        .font(.subheadline.monospaced())
                    Text("快捷指令只负责打开原 App，不能保证进入内部页面。")
                        .font(.footnote).foregroundStyle(.secondary)
                    Text("可选：若“打开 App”能选到创高体育，可创建“校园-运动”并在首页验证。")
                        .font(.footnote).foregroundStyle(.secondary)
                }

                Section("洗浴设备") {
                    Button("管理常用洗浴设备入口") { showShowerManagement = true }
                    Text("默认设备为 2153544。点击首页“洗澡”会尝试打开设备页面；可在这里扫描更换设备。")
                        .font(.footnote).foregroundStyle(.secondary)
                }

                Section("数据与隐私") {
                    Text("课程、待办和导入的消息保存在本机。应用不读取 QQ 群后台消息，也不保存学习通或微信密码、人脸照片。")
                    Text("扫码签到与支付仍在原服务中由你本人完成。")
                }

                Section("备份与恢复") {
                    Button("生成 JSON 备份") {
                        do {
                            exportURL = try BackupManager.export(context: context)
                            backupMessage = "备份已生成，请点下方按钮保存到“文件”或发送给自己。"
                        } catch {
                            backupMessage = "备份失败：\(error.localizedDescription)"
                        }
                    }
                    if let exportURL { ShareLink("分享或保存备份", item: exportURL) }
                    Button("导入 JSON 备份") { isImporting = true }
                    if let backupMessage { Text(backupMessage).font(.footnote).foregroundStyle(.secondary) }
                    Text("导入会按记录 ID 合并，不会清空当前数据。重新签名安装前建议先导出备份。")
                        .font(.footnote).foregroundStyle(.secondary)
                }

                Section("关于") {
                    Text("江财生活台 · 开发版")
                    Text("面向江西财经大学学生的个人生活助手")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("我的")
            .sheet(isPresented: $showShowerManagement) { ServiceSheet(service: .shower) }
            .task { await refreshPermission() }
            .fileImporter(isPresented: $isImporting, allowedContentTypes: [.json]) { result in
                do {
                    let url = try result.get()
                    let access = url.startAccessingSecurityScopedResource()
                    defer { if access { url.stopAccessingSecurityScopedResource() } }
                    let data = try Data(contentsOf: url)
                    backupMessage = try BackupManager.importBackup(data: data, context: context)
                    Task { await ReminderManager.rebuildFrom(context: context, termStart: termStartTimestamp > 0 ? Date(timeIntervalSince1970: termStartTimestamp) : .now) }
                } catch {
                    backupMessage = "导入失败：\(error.localizedDescription)"
                }
            }
        }
    }

    private func refreshPermission() async {
        let settings = await UNUserNotificationCenter.current().notificationSettings()
        switch settings.authorizationStatus {
        case .authorized, .provisional: notificationStatus = "已开启"
        case .denied: notificationStatus = "已关闭"
        default: notificationStatus = "未请求"
        }
    }
}
