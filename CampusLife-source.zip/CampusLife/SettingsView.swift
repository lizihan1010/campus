import SwiftData
import SwiftUI
import UIKit
import UniformTypeIdentifiers
import UserNotifications

struct SettingsView: View {
    @Environment(\.modelContext) private var context
    @Query private var courses: [CampusCourse]
    @AppStorage("termStartTimestamp") private var termStartTimestamp = 0.0
    @AppStorage("termName") private var termName = "本学期"
    @AppStorage("classReminderEnabled") private var classReminderEnabled = true
    @AppStorage("classReminderMinutes") private var classReminderMinutes = 15
    @AppStorage("liveActivityEnabled") private var liveActivityEnabled = true
    @State private var notificationStatus = "尚未检查"
    @State private var activityStatus = ""
    @State private var exportURL: URL?
    @State private var isImporting = false
    @State private var backupMessage: String?
    @State private var showShowerManagement = false

    private var termStartDate: Date {
        termStartTimestamp > 0 ? Date(timeIntervalSince1970: termStartTimestamp) : .now
    }

    private var startBinding: Binding<Date> {
        Binding(
            get: { termStartTimestamp > 0 ? Date(timeIntervalSince1970: termStartTimestamp) : TermClock.monday(of: .now) },
            set: { newDate in
                termStartTimestamp = TermClock.monday(of: newDate).timeIntervalSince1970
                Task { await rebuild() }
            }
        )
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("学期名称", text: $termName)
                    DatePicker("第一周的周一", selection: startBinding, displayedComponents: .date)
                    HStack {
                        Text("通知权限")
                        Spacer()
                        Text(notificationStatus).foregroundStyle(.secondary).font(.subheadline)
                    }
                    Button("开启提醒并重新安排") {
                        Task {
                            let granted = await ReminderManager.requestPermission()
                            notificationStatus = granted ? "已开启" : "未开启"
                            if granted { await rebuild() }
                        }
                    }
                    if notificationStatus == "已关闭" {
                        Button("去系统设置开启通知") {
                            if let url = URL(string: UIApplication.openSettingsURLString) {
                                Task { _ = await UIApplication.shared.open(url) }
                            }
                        }
                    }
                } header: {
                    Text("学期")
                } footer: {
                    Text("课表周次、单双周与所有提醒以此为准。")
                }

                Section {
                    Toggle("上课前通知我", isOn: $classReminderEnabled)
                        .onChange(of: classReminderEnabled) { _, _ in Task { await rebuild() } }
                    Picker("提前多少分钟", selection: $classReminderMinutes) {
                        ForEach(ClassReminder.choices, id: \.self) { minutes in
                            Text("\(minutes) 分钟").tag(minutes)
                        }
                    }
                    .onChange(of: classReminderMinutes) { _, _ in Task { await rebuild() } }
                } header: {
                    Text("上课提醒")
                } footer: {
                    Text("每堂课都会提前通知，标题写明课程名、时间和教室。单门课可以在「编辑课程」里单独改成别的提前量，或关掉提醒。")
                }

                Section {
                    Toggle("在灵动岛显示下一节课", isOn: $liveActivityEnabled)
                        .onChange(of: liveActivityEnabled) { _, enabled in
                            if enabled { refreshActivity() } else { LiveActivityManager.endAll() }
                            activityStatus = LiveActivityManager.statusText
                        }
                    HStack {
                        Text("当前状态")
                        Spacer()
                        Text(activityStatus).foregroundStyle(.secondary).font(.caption)
                    }
                    Button("立即刷新灵动岛") { refreshActivity(); activityStatus = LiveActivityManager.statusText }
                    Button("结束灵动岛显示") {
                        LiveActivityManager.endAll()
                        activityStatus = "已结束"
                    }
                } header: {
                    Text("灵动岛 / 实时活动")
                } footer: {
                    Text("iOS 26 会预排最近两堂课，由系统在开课时自动显示，即使应用已关闭；打开应用会继续预排后续课程。旧版 iOS 在应用前台距开课 4 小时内自动显示，每分钟检查一次。正在上课显示距下课时间。")
                }

                Section {
                    NavigationLink("全部待办与重复规则") { TaskListView() }
                    Text("只做一次 · 每周星期几 · 每隔几天")
                        .font(.caption).foregroundStyle(.secondary)
                } header: {
                    Text("自定义待办")
                } footer: {
                    Text("在「今天」或「全部待办」右上角点 + 添加。重复任务勾完成只记录当天，下一次照常出现。")
                }

                Section {
                    NavigationLink("学习通课程绑定") { ChaoxingBindingsView() }
                } header: {
                    Text("课程链接")
                } footer: {
                    Text("可为本地课程绑定学习通页面链接；课程在课表中手动添加和编辑。")
                }

                Section {
                    Text("在 iPhone「快捷指令」里创建「打开 App」操作，名称必须一致：")
                        .font(.caption).foregroundStyle(.secondary)
                    Text("校园-学习通 · 校园-喝水 · 校园-运动")
                        .font(.caption.monospaced())
                    Button("管理常用洗浴设备入口") { showShowerManagement = true }
                    Text("修猫助手口令：\(WeChatShortLink.signIn)")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                        .textSelection(.enabled)
                } header: {
                    Text("服务入口")
                } footer: {
                    Text("首页常用入口只有喝水、运动、洗澡；扫码签到仍在课程详情里。快捷指令只负责启动原 App；扫码、下单和付款都在原服务由本人完成。")
                }

                Section {
                    Button("生成 JSON 备份") {
                        do {
                            exportURL = try BackupManager.export(context: context)
                            backupMessage = "备份已生成，请点下方按钮保存到「文件」或发送给自己。"
                        } catch {
                            backupMessage = "备份失败：\(error.localizedDescription)"
                        }
                    }
                    if let exportURL { ShareLink("分享或保存备份", item: exportURL) }
                    Button("导入 JSON 备份") { isImporting = true }
                    if let backupMessage { Text(backupMessage).font(.caption).foregroundStyle(.secondary) }
                } header: {
                    Text("数据与备份")
                } footer: {
                    Text("导入按记录 ID 合并，不清空现有数据；旧备份里的待办会按「只做一次」读取。数据只存本机：不读取群聊后台，不保存学习通或微信账号、人脸照片。重新签名前建议先导出备份。")
                }

                Section {
                    Text("江财生活台 · 开发版")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("我的")
            .navigationBarTitleDisplayMode(.inline)
            .sheet(isPresented: $showShowerManagement) { ServiceSheet(service: .shower) }
            .task {
                await refreshPermission()
                activityStatus = LiveActivityManager.statusText
            }
            .fileImporter(isPresented: $isImporting, allowedContentTypes: [.json]) { result in
                do {
                    let url = try result.get()
                    let access = url.startAccessingSecurityScopedResource()
                    defer { if access { url.stopAccessingSecurityScopedResource() } }
                    let data = try Data(contentsOf: url)
                    backupMessage = try BackupManager.importBackup(data: data, context: context)
                    Task { await rebuild() }
                } catch {
                    backupMessage = "导入失败：\(error.localizedDescription)"
                }
            }
        }
    }

    private func rebuild() async {
        await ReminderManager.rebuildFrom(context: context, termStart: termStartDate)
    }

    private func refreshActivity() {
        LiveActivityManager.refresh(courses: courses, termStart: termStartDate)
    }

    private func refreshPermission() async {
        let settings = await UNUserNotificationCenter.current().notificationSettings()
        switch settings.authorizationStatus {
        case .authorized, .provisional: notificationStatus = "已开启"
        case .denied: notificationStatus = "已关闭"
        default: notificationStatus = "未请求"
        }
    }
}
