import ActivityKit
import Foundation

/// 前台核对课表；iOS 26 可让系统在预定开课时间启动实时活动。
enum LiveActivityManager {
    private typealias A = Activity<CourseActivityAttributes>
    private static let prefix = "jxufe-course:"

    static var supported: Bool { ActivityAuthorizationInfo().areActivitiesEnabled }

    static var statusText: String {
        if !ClassReminder.liveActivityEnabled { return "已关闭" }
        if !supported { return "系统未启用实时活动" }
        if A.activities.contains(where: { $0.activityState == .active }) { return "正在显示" }
        if #available(iOS 26.0, *), A.activities.contains(where: { $0.activityState == .pending }) {
            return "已排定下次上课"
        }
        return "暂无临近课程"
    }

    private static func key(_ course: CampusCourse, day: Date) -> String {
        "\(prefix)\(course.id):\(TaskSchedule.dayKey(day))"
    }

    static func show(course: CampusCourse, termStart: Date) -> String {
        guard ClassReminder.liveActivityEnabled else { return "灵动岛已在「我的 → 上课提醒」里关闭" }
        guard supported else { return "系统未启用实时活动，请到「设置 → 实时活动」检查" }
        let now = Date()
        guard TermClock.occurs(course, on: now, termStart: termStart) else { return "这节课今天不上课，不能显示为即将上课" }
        let start = TermClock.dateTime(on: now, minute: course.startMinute)
        let end = TermClock.dateTime(on: now, minute: course.endMinute)
        guard end > now else { return "这节课今天已经结束" }
        if start > now, #available(iOS 26.0, *) {
            schedule(course: course, day: now, start: start, end: end)
            return "已排定在今天 \(TermClock.time(course.startMinute)) 开课时显示「\(course.title)」"
        }
        guard start.timeIntervalSince(now) < 4 * 3600 else { return "距离上课还有 4 小时以上，临近时打开应用会自动显示" }
        apply(course: course, day: now, start: start, end: end, now: now)
        return "已请求显示「\(course.title)」；正在上课时显示距下课时间"
    }

    static func refresh(courses: [CampusCourse], termStart: Date) {
        guard ClassReminder.liveActivityEnabled, supported else { endAll(); return }
        let now = Date()
        let today = Calendar.current.startOfDay(for: now)
        let todays = courses.filter { TermClock.occurs($0, on: today, termStart: termStart) }
            .sorted { $0.startMinute < $1.startMinute }
        let ongoing = todays.first {
            TermClock.dateTime(on: today, minute: $0.startMinute) <= now &&
            TermClock.dateTime(on: today, minute: $0.endMinute) > now
        }
        var wanted = Set<String>()
        if let ongoing {
            wanted.insert(key(ongoing, day: today))
            apply(course: ongoing, day: today,
                  start: TermClock.dateTime(on: today, minute: ongoing.startMinute),
                  end: TermClock.dateTime(on: today, minute: ongoing.endMinute), now: now)
        }

        if #available(iOS 26.0, *) {
            // 系统对同时运行与待启动的活动设有数量限制，预排最近两堂。
            let upcoming = (0..<14).flatMap { offset -> [(CampusCourse, Date, Date, Date)] in
                guard let day = Calendar.current.date(byAdding: .day, value: offset, to: today) else { return [] }
                return courses.filter { TermClock.occurs($0, on: day, termStart: termStart) }
                    .map { ($0, day, TermClock.dateTime(on: day, minute: $0.startMinute), TermClock.dateTime(on: day, minute: $0.endMinute)) }
                    .filter { $0.2 > now }
            }.sorted { $0.2 < $1.2 }.prefix(2)
            for (course, day, start, end) in upcoming {
                wanted.insert(key(course, day: day))
                schedule(course: course, day: day, start: start, end: end)
            }
        } else if ongoing == nil, let next = todays.first(where: {
            let start = TermClock.dateTime(on: today, minute: $0.startMinute)
            return start > now && start.timeIntervalSince(now) < 4 * 3600
        }) {
            wanted.insert(key(next, day: today))
            apply(course: next, day: today,
                  start: TermClock.dateTime(on: today, minute: next.startMinute),
                  end: TermClock.dateTime(on: today, minute: next.endMinute), now: now)
        }
        for activity in A.activities where !wanted.contains(activity.attributes.source) {
            Task { await activity.end(nil, dismissalPolicy: .immediate) }
        }
    }

    static func endAll() {
        for activity in A.activities {
            Task { await activity.end(nil, dismissalPolicy: .immediate) }
        }
    }

    @available(iOS 26.0, *)
    private static func schedule(course: CampusCourse, day: Date, start: Date, end: Date) {
        let source = key(course, day: day)
        guard !A.activities.contains(where: { $0.attributes.source == source }) else { return }
        let state = state(for: course, start: start, end: end, now: start)
        do {
            _ = try A.request(
                attributes: CourseActivityAttributes(source: source),
                content: ActivityContent(state: state, staleDate: end, relevanceScore: start.timeIntervalSince1970),
                pushType: nil,
                style: .standard,
                alertConfiguration: AlertConfiguration(title: "上课了", body: "请查看课表", sound: .default),
                start: start
            )
        } catch {
            print("排定实时活动失败：\(error.localizedDescription)")
        }
    }

    private static func apply(course: CampusCourse, day: Date, start: Date, end: Date, now: Date) {
        let source = key(course, day: day)
        let content = ActivityContent(state: state(for: course, start: start, end: end, now: now), staleDate: end)
        if let activity = A.activities.first(where: { $0.attributes.source == source }) {
            Task { await activity.update(content) }
        } else {
            do {
                _ = try A.request(attributes: CourseActivityAttributes(source: source), content: content)
            } catch {
                print("启动实时活动失败：\(error.localizedDescription)")
            }
        }
    }

    private static func state(for course: CampusCourse, start: Date, end: Date, now: Date) -> CourseActivityAttributes.ContentState {
        let inClass = now >= start && now < end
        return .init(
            phase: inClass ? "正在上课" : "下一节课",
            courseTitle: course.title,
            location: course.location.isEmpty ? "教室未填写" : course.location,
            startTime: TermClock.time(course.startMinute),
            endTime: TermClock.time(course.endMinute),
            targetAt: inClass ? end : start,
            targetLabel: inClass ? "距下课" : "距开课"
        )
    }
}
