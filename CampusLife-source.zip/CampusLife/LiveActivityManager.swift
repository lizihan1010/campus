import ActivityKit
import Foundation

/// 灵动岛 / 实时活动的启动与刷新。
///
/// 重要限制（写在 README 里）：本 App 没有推送服务器，也没有 APNs 凭证，
/// 实时活动只能由前台运行的 App 发起或更新。打开 App、回到前台、修改课表、
/// 修改提醒设置时都会刷新；此后倒计时由系统自行更新，直到下一次打开 App。
/// 灵动岛需要 iPhone 14 Pro 及以上机型，其他机型只会显示在锁屏通知区。
/// 这里刻意不做 @MainActor 隔离：ActivityKit 的 API 本身不要求主线程，
/// 从 SwiftUI 的按钮闭包里同步调用也能顺利编译。
enum LiveActivityManager {
    private typealias A = Activity<CourseActivityAttributes>

    static var supported: Bool {
        ActivityAuthorizationInfo().areActivitiesEnabled
    }

    static var statusText: String {
        if !ClassReminder.liveActivityEnabled { return "已关闭" }
        if !supported { return "系统未启用实时活动" }
        return A.activities.isEmpty ? "待显示（打开 App 自动出现）" : "正在显示"
    }

    /// 课程详情里手动「在灵动岛显示这节课」
    static func show(course: CampusCourse, on day: Date = .now) -> String {
        guard ClassReminder.liveActivityEnabled else { return "灵动岛已在「我的 → 上课提醒」里关闭" }
        guard supported else { return "系统未启用实时活动，请到「设置 → 实时活动」检查" }
        let start = TermClock.dateTime(on: day, minute: course.startMinute)
        let end = TermClock.dateTime(on: day, minute: course.endMinute)
        apply(course: course, start: start, end: end, now: .now)
        return "已请求在灵动岛显示「\(course.title)」；锁屏与灵动岛由系统渲染"
    }

    /// App 前台 / 通知重排时自动刷新到「当前该关注的那一节课」
    static func refresh(courses: [CampusCourse], termStart: Date) {
        guard ClassReminder.liveActivityEnabled, supported else { return }
        let now = Date()
        let calendar = Calendar.current
        var best: (course: CampusCourse, start: Date, end: Date)?

        for offset in 0..<2 {
            guard let day = calendar.date(byAdding: .day, value: offset, to: calendar.startOfDay(for: now)) else { continue }
            for course in courses where TermClock.occurs(course, on: day, termStart: termStart) {
                let start = TermClock.dateTime(on: day, minute: course.startMinute)
                let end = TermClock.dateTime(on: day, minute: course.endMinute)
                guard end > now else { continue }
                if let current = best {
                    if start < current.start { best = (course, start, end) }
                } else {
                    best = (course, start, end)
                }
            }
        }

        // 只保留正在上的课，或 4 小时内即将开始的课；避免出现一整晚的过期活动
        guard let hit = best, hit.start.timeIntervalSince(now) < 4 * 3600 else {
            endAll()
            return
        }
        apply(course: hit.course, start: hit.start, end: hit.end, now: now)
    }

    static func endAll() {
        let activities = A.activities
        guard !activities.isEmpty else { return }
        Task {
            for activity in activities {
                await activity.end(nil, dismissalPolicy: .immediate)
            }
        }
    }

    private static func apply(course: CampusCourse, start: Date, end: Date, now: Date) {
        let inClass = now >= start && now < end
        let state = CourseActivityAttributes.ContentState(
            phase: inClass ? "正在上课" : "下一节课",
            courseTitle: course.title,
            location: course.location.isEmpty ? "教室未填写" : course.location,
            startTime: TermClock.time(course.startMinute),
            endTime: TermClock.time(course.endMinute),
            targetAt: inClass ? end : start,
            targetLabel: inClass ? "下课" : "开课"
        )
        let attributes = CourseActivityAttributes(source: "jxufe-course")
        if let activity = A.activities.first {
            Task { await activity.update(using: state) }
        } else {
            do {
                _ = try A.request(attributes: attributes, contentState: state)
            } catch {
                print("启动实时活动失败：\(error.localizedDescription)")
            }
        }
    }
}
