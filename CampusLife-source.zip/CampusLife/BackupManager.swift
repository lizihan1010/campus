import Foundation
import SwiftData

private struct CampusBackup: Codable {
    struct Course: Codable {
        let id: UUID
        let title: String
        let location: String
        let teacher: String
        let weekday: Int
        let startMinute: Int
        let endMinute: Int
        let firstWeek: Int
        let lastWeek: Int
        let weekMode: Int
        let note: String
    }
    struct TaskItem: Codable {
        let id: UUID
        let title: String
        let details: String
        let dueAt: Date
        let isDone: Bool
        let reminderMinutes: Int
        let sourceText: String
        let createdAt: Date
    }
    struct Note: Codable {
        let id: UUID
        let content: String
        let source: String
        let createdAt: Date
        let isProcessed: Bool
    }
    let version: Int
    let termName: String
    let termStartTimestamp: Double
    let courses: [Course]
    let tasks: [TaskItem]
    let notes: [Note]
}

enum BackupManager {
    @MainActor
    static func export(context: ModelContext) throws -> URL {
        let courses = try context.fetch(FetchDescriptor<CampusCourse>())
        let tasks = try context.fetch(FetchDescriptor<CampusTask>())
        let notes = try context.fetch(FetchDescriptor<InboxNote>())
        let backup = CampusBackup(
            version: 1,
            termName: UserDefaults.standard.string(forKey: "termName") ?? "本学期",
            termStartTimestamp: UserDefaults.standard.double(forKey: "termStartTimestamp"),
            courses: courses.map { .init(id: $0.id, title: $0.title, location: $0.location, teacher: $0.teacher, weekday: $0.weekday, startMinute: $0.startMinute, endMinute: $0.endMinute, firstWeek: $0.firstWeek, lastWeek: $0.lastWeek, weekMode: $0.weekMode, note: $0.note) },
            tasks: tasks.map { .init(id: $0.id, title: $0.title, details: $0.details, dueAt: $0.dueAt, isDone: $0.isDone, reminderMinutes: $0.reminderMinutes, sourceText: $0.sourceText, createdAt: $0.createdAt) },
            notes: notes.map { .init(id: $0.id, content: $0.content, source: $0.source, createdAt: $0.createdAt, isProcessed: $0.isProcessed) }
        )
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        let data = try encoder.encode(backup)
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("江财生活台备份.json")
        try data.write(to: url, options: .atomic)
        return url
    }

    @MainActor
    static func importBackup(data: Data, context: ModelContext) throws -> String {
        guard data.count <= 10_000_000 else { throw BackupError.tooLarge }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        let backup = try decoder.decode(CampusBackup.self, from: data)
        guard backup.version == 1 else { throw BackupError.unsupportedVersion }
        guard Set(backup.courses.map(\.id)).count == backup.courses.count,
              Set(backup.tasks.map(\.id)).count == backup.tasks.count,
              Set(backup.notes.map(\.id)).count == backup.notes.count else { throw BackupError.duplicateID }
        guard backup.courses.allSatisfy({ (1...7).contains($0.weekday) && $0.startMinute >= 0 && $0.endMinute <= 1440 && $0.endMinute > $0.startMinute && $0.firstWeek >= 1 && $0.lastWeek >= $0.firstWeek && (0...2).contains($0.weekMode) }) else {
            throw BackupError.invalidCourse
        }

        let oldCourses = Dictionary(try context.fetch(FetchDescriptor<CampusCourse>()).map { ($0.id, $0) }, uniquingKeysWith: { first, _ in first })
        let oldTasks = Dictionary(try context.fetch(FetchDescriptor<CampusTask>()).map { ($0.id, $0) }, uniquingKeysWith: { first, _ in first })
        let oldNotes = Dictionary(try context.fetch(FetchDescriptor<InboxNote>()).map { ($0.id, $0) }, uniquingKeysWith: { first, _ in first })
        for item in backup.courses {
            let course = oldCourses[item.id] ?? CampusCourse(title: item.title, weekday: item.weekday, startMinute: item.startMinute, endMinute: item.endMinute)
            course.id = item.id
            course.title = item.title
            course.location = item.location
            course.teacher = item.teacher
            course.weekday = item.weekday
            course.startMinute = item.startMinute
            course.endMinute = item.endMinute
            course.firstWeek = item.firstWeek
            course.lastWeek = item.lastWeek
            course.weekMode = item.weekMode
            course.note = item.note
            if oldCourses[item.id] == nil { context.insert(course) }
        }
        for item in backup.tasks {
            let task = oldTasks[item.id] ?? CampusTask(title: item.title, dueAt: item.dueAt)
            task.id = item.id
            task.title = item.title
            task.details = item.details
            task.dueAt = item.dueAt
            task.isDone = item.isDone
            task.reminderMinutes = item.reminderMinutes
            task.sourceText = item.sourceText
            task.createdAt = item.createdAt
            if oldTasks[item.id] == nil { context.insert(task) }
        }
        for item in backup.notes {
            let note = oldNotes[item.id] ?? InboxNote(content: item.content, source: item.source)
            note.id = item.id
            note.content = item.content
            note.source = item.source
            note.createdAt = item.createdAt
            note.isProcessed = item.isProcessed
            if oldNotes[item.id] == nil { context.insert(note) }
        }
        try context.save()
        UserDefaults.standard.set(backup.termName, forKey: "termName")
        UserDefaults.standard.set(backup.termStartTimestamp, forKey: "termStartTimestamp")
        return "已合并 \(backup.courses.count) 门课程、\(backup.tasks.count) 项待办、\(backup.notes.count) 条消息"
    }
}

enum BackupError: LocalizedError {
    case tooLarge, unsupportedVersion, invalidCourse, duplicateID
    var errorDescription: String? {
        switch self {
        case .tooLarge: "备份文件不能超过 10 MB"
        case .unsupportedVersion: "备份版本暂不支持"
        case .invalidCourse: "备份中的课程时间或周次无效"
        case .duplicateID: "备份里有重复的记录 ID"
        }
    }
}
