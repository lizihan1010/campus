import SwiftData
import SwiftUI

struct CourseEditor: View {
    let course: CampusCourse?
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var context
    @AppStorage("termStartTimestamp") private var termStartTimestamp = 0.0

    @State private var title: String
    @State private var location: String
    @State private var teacher: String
    @State private var weekday: Int
    @State private var startTime: Date
    @State private var endTime: Date
    @State private var firstWeek: Int
    @State private var lastWeek: Int
    @State private var weekMode: Int
    @State private var note: String
    @State private var reminderOverride: Int

    init(course: CampusCourse? = nil) {
        self.course = course
        let midnight = Calendar.current.startOfDay(for: .now)
        _title = State(initialValue: course?.title ?? "")
        _location = State(initialValue: course?.location ?? "")
        _teacher = State(initialValue: course?.teacher ?? "")
        _weekday = State(initialValue: course?.weekday ?? 1)
        _startTime = State(initialValue: midnight.addingTimeInterval(TimeInterval((course?.startMinute ?? 480) * 60)))
        _endTime = State(initialValue: midnight.addingTimeInterval(TimeInterval((course?.endMinute ?? 575) * 60)))
        _firstWeek = State(initialValue: course?.firstWeek ?? 1)
        _lastWeek = State(initialValue: course?.lastWeek ?? 20)
        _weekMode = State(initialValue: course?.weekMode ?? 0)
        _note = State(initialValue: course?.note ?? "")
        _reminderOverride = State(initialValue: course?.reminderOverride ?? 0)
    }

    private var startMinute: Int { Calendar.current.component(.hour, from: startTime) * 60 + Calendar.current.component(.minute, from: startTime) }
    private var endMinute: Int { Calendar.current.component(.hour, from: endTime) * 60 + Calendar.current.component(.minute, from: endTime) }
    private var valid: Bool { !title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && endMinute > startMinute && lastWeek >= firstWeek }

    var body: some View {
        NavigationStack {
            Form {
                Section("课程") {
                    TextField("课程名称", text: $title)
                    TextField("教室", text: $location)
                    TextField("教师", text: $teacher)
                }
                Section("时间") {
                    Picker("星期", selection: $weekday) {
                        ForEach(1...7, id: \.self) { day in Text(TermClock.weekdays[day - 1]).tag(day) }
                    }
                    DatePicker("开始", selection: $startTime, displayedComponents: .hourAndMinute)
                    DatePicker("结束", selection: $endTime, displayedComponents: .hourAndMinute)
                    Stepper("第 \(firstWeek) 周开始", value: $firstWeek, in: 1...30)
                    Stepper("第 \(lastWeek) 周结束", value: $lastWeek, in: 1...30)
                    Picker("周次", selection: $weekMode) {
                        Text("每周").tag(0)
                        Text("单周").tag(1)
                        Text("双周").tag(2)
                    }
                }
                Section {
                    Picker("提前量", selection: $reminderOverride) {
                        ForEach(ClassReminder.overrideChoices, id: \.self) { value in
                            Text(ClassReminder.overrideLabel(value)).tag(value)
                        }
                    }
                } header: {
                    Text("这节课的上课提醒")
                } footer: {
                    Text("「跟随全局」使用「我的 → 上课提醒」里设置的分钟数；也可以单独关掉某一门课，或给它设不同的提前量。通知标题会写出课程名、时间和教室。")
                }
                Section("备注") { TextField("课程群或注意事项", text: $note, axis: .vertical) }
                if !valid { Text("请填写课程名称，并确认结束时间晚于开始时间、结束周不早于开始周。").font(.footnote).foregroundStyle(.secondary) }
            }
            .navigationTitle(course == nil ? "添加课程" : "编辑课程")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) { Button("保存") { save() }.disabled(!valid) }
            }
        }
    }

    private func save() {
        let cleanTitle = title.trimmingCharacters(in: .whitespacesAndNewlines)
        if let course {
            course.title = cleanTitle
            course.location = location
            course.teacher = teacher
            course.weekday = weekday
            course.startMinute = startMinute
            course.endMinute = endMinute
            course.firstWeek = firstWeek
            course.lastWeek = lastWeek
            course.weekMode = weekMode
            course.note = note
            course.reminderOverride = reminderOverride
        } else {
            context.insert(CampusCourse(title: cleanTitle, location: location, teacher: teacher, weekday: weekday, startMinute: startMinute, endMinute: endMinute, firstWeek: firstWeek, lastWeek: lastWeek, weekMode: weekMode, note: note, reminderOverride: reminderOverride))
        }
        try? context.save()
        if termStartTimestamp > 0 {
            Task { await ReminderManager.rebuildFrom(context: context, termStart: Date(timeIntervalSince1970: termStartTimestamp)) }
        }
        dismiss()
    }
}

private let shortWeekdays = ["一", "二", "三", "四", "五", "六", "日"]

struct TaskEditor: View {
    let task: CampusTask?
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var context
    @AppStorage("termStartTimestamp") private var termStartTimestamp = 0.0

    @State private var title: String
    @State private var details: String
    @State private var dueAt: Date
    @State private var reminderMinutes: Int
    @State private var sourceText: String
    @State private var repeatKind: Int
    @State private var repeatWeekdays: [Int]
    @State private var repeatInterval: Int
    @State private var startDate: Date

    init(task: CampusTask? = nil, sourceText: String = "") {
        self.task = task
        _title = State(initialValue: task?.title ?? "")
        _details = State(initialValue: task?.details ?? "")
        _dueAt = State(initialValue: task?.dueAt ?? Calendar.current.date(byAdding: .day, value: 1, to: .now) ?? .now)
        _reminderMinutes = State(initialValue: task?.reminderMinutes ?? 60)
        _sourceText = State(initialValue: task?.sourceText ?? sourceText)
        _repeatKind = State(initialValue: task?.repeatKind ?? 0)
        _repeatWeekdays = State(initialValue: task?.repeatWeekdays ?? [])
        _repeatInterval = State(initialValue: task?.repeatInterval ?? 2)
        _startDate = State(initialValue: task?.startDate ?? .now)
    }

    private var valid: Bool {
        guard !title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return false }
        if repeatKind == 1 { return !repeatWeekdays.isEmpty }
        return true
    }

    private var kindHint: String {
        TaskRepeatKind(rawValue: repeatKind)?.hint ?? ""
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("要做什么") {
                    TextField("标题，例如：背单词 / 交作业 / 去跑步", text: $title)
                    TextField("补充说明（可选）", text: $details, axis: .vertical)
                }

                Section {
                    Picker("重复方式", selection: $repeatKind) {
                        ForEach(TaskRepeatKind.allCases) { kind in
                            Text(kind.label).tag(kind.rawValue)
                        }
                    }
                    Text(kindHint).font(.caption).foregroundStyle(.secondary)

                    if repeatKind == 0 {
                        DatePicker("截止时间", selection: $dueAt)
                    } else {
                        DatePicker("每次的时间", selection: $dueAt, displayedComponents: .hourAndMinute)
                        DatePicker("从哪天开始", selection: $startDate, displayedComponents: .date)
                        if repeatKind == 1 {
                            weekdayPicker
                        } else {
                            Stepper(value: $repeatInterval, in: 1...60) {
                                Text("每隔 \(repeatInterval) 天做一次")
                            }
                        }
                    }
                } header: {
                    Text("做几次")
                } footer: {
                    Text("重复任务勾「完成」只记录当天已完成，下一次照常出现；单次任务勾完即结束。")
                }

                Section {
                    Picker("提前提醒", selection: $reminderMinutes) {
                        Text("不提醒").tag(-1)
                        Text("准时").tag(0)
                        Text("提前 15 分钟").tag(15)
                        Text("提前 1 小时").tag(60)
                        Text("提前 1 天").tag(1440)
                    }
                } header: {
                    Text("提醒")
                } footer: {
                    Text("每次执行都会单独排一条本地通知，最多排未来 14 天、共 50 条。")
                }

                if !sourceText.isEmpty {
                    Section("原始信息") { Text(sourceText).font(.footnote).foregroundStyle(.secondary) }
                }
            }
            .navigationTitle(task == nil ? "添加待办" : "编辑待办")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) { Button("保存") { save() }.disabled(!valid) }
            }
        }
    }

    private var weekdayPicker: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(1...7, id: \.self) { day in
                    Button {
                        if let index = repeatWeekdays.firstIndex(of: day) {
                            repeatWeekdays.remove(at: index)
                        } else {
                            repeatWeekdays.append(day)
                        }
                    } label: {
                        Text(shortWeekdays[day - 1])
                            .font(.subheadline.weight(.semibold))
                            .frame(width: 34, height: 34)
                            .background(
                                repeatWeekdays.contains(day) ? CampusPalette.primary : CampusPalette.card,
                                in: Circle()
                            )
                            .foregroundStyle(repeatWeekdays.contains(day) ? Color.white : Color.primary)
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("周\(shortWeekdays[day - 1])")
                }
            }
            .padding(.vertical, 4)
        }
    }

    private func save() {
        let cleanTitle = title.trimmingCharacters(in: .whitespacesAndNewlines)
        if let task {
            task.title = cleanTitle
            task.details = details
            task.dueAt = dueAt
            task.reminderMinutes = reminderMinutes
            task.repeatKind = repeatKind
            task.repeatWeekdays = repeatKind == 1 ? repeatWeekdays.sorted() : []
            task.repeatInterval = max(1, repeatInterval)
            task.startDate = startDate
        } else {
            context.insert(CampusTask(
                title: cleanTitle,
                details: details,
                dueAt: dueAt,
                reminderMinutes: reminderMinutes,
                sourceText: sourceText,
                repeatKind: repeatKind,
                repeatWeekdays: repeatKind == 1 ? repeatWeekdays.sorted() : [],
                repeatInterval: max(1, repeatInterval),
                startDate: startDate
            ))
        }
        try? context.save()
        Task { await ReminderManager.rebuildFrom(context: context, termStart: termStartTimestamp > 0 ? Date(timeIntervalSince1970: termStartTimestamp) : .now) }
        dismiss()
    }
}
