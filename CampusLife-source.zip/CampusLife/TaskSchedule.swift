import Foundation

/// 自己添加的事情：只做一次 / 每周指定星期几 / 每隔 N 天。
enum TaskRepeatKind: Int, CaseIterable, Identifiable {
    case once = 0
    case weekly = 1
    case interval = 2

    var id: Int { rawValue }

    var label: String {
        switch self {
        case .once: "只做一次"
        case .weekly: "每周固定几天"
        case .interval: "每隔几天"
        }
    }

    var hint: String {
        switch self {
        case .once: "在设定的截止时间提醒一次"
        case .weekly: "勾选星期几，每周这些天各提醒一次"
        case .interval: "从起始日算起，每隔 N 天提醒一次"
        }
    }
}

enum TaskSchedule {
    /// 本地提醒最多排未来 14 天，与 iOS 待处理通知数量预算一致
    static let horizonDays = 14

    static func dayKey(_ date: Date) -> String {
        let c = Calendar.current.dateComponents([.year, .month, .day], from: date)
        return String(format: "%04d-%02d-%02d", c.year ?? 1970, c.month ?? 1, c.day ?? 1)
    }

    static func date(on day: Date, timeOf dueAt: Date) -> Date {
        let c = Calendar.current.dateComponents([.hour, .minute], from: dueAt)
        return Calendar.current.date(
            bySettingHour: c.hour ?? 20,
            minute: c.minute ?? 0,
            second: 0,
            of: Calendar.current.startOfDay(for: day)
        ) ?? day
    }

    /// 某一天是否是这个任务的执行日（不判断当天是否已完成）
    static func occursOn(_ task: CampusTask, day: Date) -> Bool {
        let calendar = Calendar.current
        let start = calendar.startOfDay(for: day)
        let anchor = calendar.startOfDay(for: task.startDate)
        switch task.repeatKind {
        case 1:
            guard start >= anchor else { return false }
            return task.repeatWeekdays.contains(TermClock.weekday(of: day))
        case 2:
            let delta = calendar.dateComponents([.day], from: anchor, to: start).day ?? -1
            return delta >= 0 && delta % max(1, task.repeatInterval) == 0
        default:
            return calendar.isDate(start, inSameDayAs: task.dueAt)
        }
    }

    static func isDone(_ task: CampusTask, on date: Date = .now) -> Bool {
        if task.repeatKind == 0 { return task.isDone }
        return task.doneDates.contains(dayKey(date))
    }

    /// 单次任务勾完成；重复任务只记录「今天已完成」，下个周期照常出现。
    static func toggleDone(_ task: CampusTask, on date: Date = .now) {
        if task.repeatKind == 0 {
            task.isDone.toggle()
            return
        }
        let key = dayKey(date)
        if let index = task.doneDates.firstIndex(of: key) {
            task.doneDates.remove(at: index)
        } else {
            task.doneDates.append(key)
        }
    }

    /// 未来 horizonDays 天内所有尚未完成的执行时刻
    static func occurrences(_ task: CampusTask, from day: Date = .now, days: Int = horizonDays) -> [Date] {
        guard task.hasTime else { return [] }
        let calendar = Calendar.current
        let start = calendar.startOfDay(for: day)
        if task.repeatKind == 0 {
            guard !task.isDone, task.dueAt >= start else { return [] }
            guard let limit = calendar.date(byAdding: .day, value: days, to: start), task.dueAt < limit else { return [] }
            return [task.dueAt]
        }
        var result: [Date] = []
        for offset in 0..<max(1, days) {
            guard let current = calendar.date(byAdding: .day, value: offset, to: start) else { continue }
            guard occursOn(task, day: current), !doneDatesContains(task, key: dayKey(current)) else { continue }
            let fire = date(on: current, timeOf: task.dueAt)
            if fire >= start { result.append(fire) }
        }
        return result
    }

    private static func doneDatesContains(_ task: CampusTask, key: String) -> Bool {
        task.doneDates.contains(key)
    }

    static func nextOccurrence(_ task: CampusTask) -> Date? {
        if task.repeatKind == 0 { return task.isDone ? nil : task.dueAt }
        if !task.hasTime {
            let calendar = Calendar.current
            for offset in 0..<horizonDays {
                guard let day = calendar.date(byAdding: .day, value: offset, to: calendar.startOfDay(for: .now)) else { continue }
                if occursOn(task, day: day), !isDone(task, on: day) { return day }
            }
            return nil
        }
        return occurrences(task).first
    }

    /// 今天首页是否展示这条待办
    static func isOpen(_ task: CampusTask, on date: Date = .now) -> Bool {
        if task.repeatKind == 0 {
            return !task.isDone && (task.hasTime || Calendar.current.startOfDay(for: task.dueAt) <= Calendar.current.startOfDay(for: date))
        }
        return !isDone(task, on: date) && occursOn(task, day: date)
    }

    static func summary(_ task: CampusTask) -> String {
        switch task.repeatKind {
        case 1:
            let days = task.repeatWeekdays.sorted().compactMap { day -> String? in
                guard (1...7).contains(day) else { return nil }
                return TermClock.weekdays[day - 1].replacingOccurrences(of: "周", with: "")
            }
            return days.isEmpty ? "每周（未选星期）" : "每周 " + days.joined(separator: "、")
        case 2:
            return "每隔 \(max(1, task.repeatInterval)) 天"
        default:
            return "只做一次"
        }
    }

    static func displayDate(_ date: Date, for task: CampusTask) -> String {
        task.hasTime
            ? date.formatted(.dateTime.month().day().hour().minute())
            : date.formatted(.dateTime.month().day())
    }
}
