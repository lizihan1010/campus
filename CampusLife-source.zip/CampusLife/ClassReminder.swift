import Foundation

/// 上课提醒的可配置项。全局值存 UserDefaults，单门课可在「编辑课程」里覆盖。
enum ClassReminder {
    static let enabledKey = "classReminderEnabled"
    static let minutesKey = "classReminderMinutes"
    static let liveEnabledKey = "liveActivityEnabled"

    static let choices = [5, 10, 15, 20, 30, 45, 60]
    /// -1 = 不提醒，0 = 跟随全局，正数 = 提前 N 分钟
    static let overrideChoices = [-1, 0, 5, 10, 15, 20, 30, 60]

    static var isEnabled: Bool {
        UserDefaults.standard.object(forKey: enabledKey) as? Bool ?? true
    }

    static var minutes: Int {
        let value = UserDefaults.standard.integer(forKey: minutesKey)
        return value > 0 ? value : 15
    }

    static var liveActivityEnabled: Bool {
        UserDefaults.standard.object(forKey: liveEnabledKey) as? Bool ?? true
    }

    /// 返回这节课应该提前多少分钟提醒；nil 表示不提醒。
    static func offset(for course: CampusCourse) -> Int? {
        if course.reminderOverride < 0 { return nil }
        if course.reminderOverride > 0 { return course.reminderOverride }
        return isEnabled ? minutes : nil
    }

    static func overrideLabel(_ value: Int) -> String {
        switch value {
        case -1: "不提醒"
        case 0: "跟随全局"
        default: "提前 \(value) 分钟"
        }
    }
}
