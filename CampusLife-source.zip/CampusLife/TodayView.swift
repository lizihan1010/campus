import SwiftData
import SwiftUI

struct TodayView: View {
    @Query private var courses: [CampusCourse]
    @Query(sort: \CampusTask.dueAt) private var tasks: [CampusTask]
    @Environment(\.modelContext) private var context
    @AppStorage("termStartTimestamp") private var termStartTimestamp = 0.0
    @AppStorage("termName") private var termName = "本学期"

    @State private var showTaskEditor = false
    @State private var selectedService: CampusService?

    private var termStart: Date { Date(timeIntervalSince1970: termStartTimestamp) }
    private var todaysCourses: [CampusCourse] {
        guard termStartTimestamp > 0 else { return [] }
        return courses.filter { TermClock.occurs($0, on: .now, termStart: termStart) }.sorted { $0.startMinute < $1.startMinute }
    }
    private var openTasks: [CampusTask] { tasks.filter { !$0.isDone } }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    header

                    if termStartTimestamp == 0 {
                        CampusCard {
                            Label("先到“我的”设置学期第一周的周一", systemImage: "calendar.badge.exclamationmark")
                                .foregroundStyle(CampusPalette.primary)
                        }
                        .padding(.horizontal, 20)
                    }

                    HStack {
                        SectionHeader(title: "接下来", subtitle: "课程与待办")
                        NavigationLink("全部待办") { TaskListView() }
                            .font(.subheadline)
                            .padding(.trailing, 20)
                    }
                    VStack(spacing: 10) {
                        ForEach(todaysCourses) { course in
                            NavigationLink { CourseDetailView(course: course) } label: {
                                CampusCard {
                                    HStack(spacing: 14) {
                                        timeBadge(TermClock.time(course.startMinute))
                                        VStack(alignment: .leading, spacing: 4) {
                                            Text(course.title).font(.headline).foregroundStyle(.primary)
                                            Text(course.location.isEmpty ? "教室未填写" : course.location).font(.subheadline).foregroundStyle(.secondary)
                                        }
                                        Spacer()
                                        Image(systemName: "chevron.right").font(.caption).foregroundStyle(.tertiary)
                                    }
                                }
                            }
                            .buttonStyle(.plain)
                        }
                        ForEach(openTasks.prefix(4)) { task in
                            CampusCard {
                                HStack(spacing: 14) {
                                    Button {
                                        task.isDone = true
                                        try? context.save()
                                        Task { await ReminderManager.rebuildFrom(context: context, termStart: termStartTimestamp > 0 ? termStart : .now) }
                                    } label: {
                                        Image(systemName: "circle").font(.title3).foregroundStyle(CampusPalette.primary)
                                    }
                                    .accessibilityLabel("完成\(task.title)")
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(task.title).font(.headline)
                                        Text(task.dueAt, format: .dateTime.month().day().hour().minute())
                                            .font(.subheadline)
                                            .foregroundStyle(task.dueAt < .now ? Color.red : CampusPalette.muted)
                                    }
                                    Spacer()
                                }
                            }
                        }
                        if todaysCourses.isEmpty && openTasks.isEmpty {
                            CampusCard { EmptyMessage(symbol: "sparkles", title: "今天暂时很清爽", message: "添加课表或待办后，这里会按时间显示。") }
                        }
                    }
                    .padding(.horizontal, 20)

                    SectionHeader(title: "常用入口", subtitle: "操作仍在原服务完成")
                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                        ForEach(CampusService.allCases) { service in
                            Button { selectedService = service } label: {
                                CampusCard {
                                    HStack(spacing: 12) {
                                        Image(systemName: service.symbol)
                                            .font(.title3)
                                            .foregroundStyle(CampusPalette.primary)
                                            .frame(width: 36, height: 36)
                                            .background(CampusPalette.primary.opacity(0.10), in: RoundedRectangle(cornerRadius: 11))
                                        VStack(alignment: .leading, spacing: 2) {
                                            Text(service.title).font(.subheadline.bold()).foregroundStyle(.primary)
                                            Text(service.status).font(.caption2).foregroundStyle(.secondary)
                                        }
                                    }
                                }
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.horizontal, 20)
                }
                .padding(.vertical, 20)
            }
            .background(CampusPalette.background)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showTaskEditor = true } label: { Image(systemName: "plus.circle.fill").font(.title3) }
                        .accessibilityLabel("添加待办")
                }
            }
            .sheet(isPresented: $showTaskEditor) { TaskEditor() }
            .sheet(item: $selectedService) { service in ServiceSheet(service: service) }
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(Date.now.formatted(.dateTime.month(.wide).day().weekday(.wide)))
                .font(.subheadline).foregroundStyle(CampusPalette.muted)
            Text("今天要做什么").font(.system(size: 32, weight: .bold, design: .rounded))
            Text(termStartTimestamp > 0 ? "\(termName) · 第 \(TermClock.weekNumber(on: .now, termStart: termStart)) 周" : "设置学期后显示教学周")
                .font(.subheadline).foregroundStyle(.secondary)
        }
        .padding(.horizontal, 20)
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func timeBadge(_ time: String) -> some View {
        Text(time).font(.caption.bold()).monospacedDigit()
            .foregroundStyle(CampusPalette.primary)
            .padding(.horizontal, 9).padding(.vertical, 7)
            .background(CampusPalette.primary.opacity(0.10), in: Capsule())
    }
}
