import SwiftData
import SwiftUI
import UIKit

struct TodayView: View {
    @Query private var courses: [CampusCourse]
    @Query(sort: \CampusTask.dueAt) private var tasks: [CampusTask]
    @Environment(\.modelContext) private var context
    @AppStorage("termStartTimestamp") private var termStartTimestamp = 0.0
    @AppStorage("termName") private var termName = "本学期"
    @AppStorage("classReminderMinutes") private var classReminderMinutes = 15
    @AppStorage("classReminderEnabled") private var classReminderEnabled = true
    @AppStorage("liveActivityEnabled") private var liveActivityEnabled = true

    @State private var showTaskEditor = false
    @State private var selectedService: CampusService?

    private var termStart: Date { Date(timeIntervalSince1970: termStartTimestamp) }
    private var todaysCourses: [CampusCourse] {
        guard termStartTimestamp > 0 else { return [] }
        return courses.filter { TermClock.occurs($0, on: .now, termStart: termStart) }
            .sorted { $0.startMinute < $1.startMinute }
    }
    private var openTasks: [CampusTask] { tasks.filter { TaskSchedule.isOpen($0) } }
    private var nextCourse: CampusCourse? {
        let calendar = Calendar.current
        let nowMinute = calendar.component(.hour, from: .now) * 60 + calendar.component(.minute, from: .now)
        return todaysCourses.first { $0.endMinute >= nowMinute } ?? todaysCourses.first
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    header.padding(.horizontal, 16)

                    if termStartTimestamp == 0 {
                        Text("到「我的」设置学期第一周的周一，即可显示教学周和课程。")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .padding(.horizontal, 16)
                    }

                    if let course = nextCourse {
                        nextClassCard(course).padding(.horizontal, 16)
                        reminderStrip(course).padding(.horizontal, 18)
                    }

                    HStack {
                        Text("课程与待办").font(.headline)
                        Spacer()
                        NavigationLink("全部待办 ›") { TaskListView() }.font(.caption)
                    }
                    .padding(.horizontal, 16)

                    VStack(spacing: 8) {
                        ForEach(todaysCourses) { course in courseRow(course) }
                        ForEach(openTasks.prefix(3)) { task in taskRow(task) }
                        if todaysCourses.isEmpty && openTasks.isEmpty {
                            CampusCard {
                                EmptyMessage(symbol: "sparkles", title: "今天没有课，也没有待办", message: "点右上角 + 可以添加一项待办。")
                            }
                        }
                    }
                    .padding(.horizontal, 16)

                    Text("常用入口").font(.headline).padding(.horizontal, 16)
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 12) {
                            ForEach(CampusService.quickEntries) { service in
                                Button { handle(service) } label: {
                                    VStack(spacing: 6) {
                                        Image(systemName: service.symbol)
                                            .font(.title3)
                                            .frame(width: 46, height: 46)
                                            .background(CampusPalette.soft, in: RoundedRectangle(cornerRadius: 13, style: .continuous))
                                        Text(service.title).font(.caption2)
                                        Text(service.status).font(.caption2).foregroundStyle(.secondary)
                                    }
                                    .frame(width: 72)
                                }
                                .buttonStyle(.plain)
                                .foregroundStyle(CampusPalette.primary)
                            }
                        }
                        .padding(.horizontal, 16)
                    }
                }
                .padding(.vertical, 16)
            }
            .background(CampusPalette.background)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showTaskEditor = true } label: {
                        Image(systemName: "plus.circle.fill")
                            .font(.title3)
                            .frame(width: 44, height: 44)
                            .contentShape(Rectangle())
                    }
                    .accessibilityLabel("添加待办")
                }
            }
            .sheet(isPresented: $showTaskEditor) { TaskEditor() }
            .sheet(item: $selectedService) { ServiceSheet(service: $0) }
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(Date.now.formatted(.dateTime.month(.wide).day().weekday(.wide)))
                .font(.caption)
                .foregroundStyle(.secondary)
            Text(termStartTimestamp > 0
                 ? "\(termName) · 第 \(TermClock.weekNumber(on: .now, termStart: termStart)) 周"
                 : "今天")
                .font(.title3.bold())
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func nextClassCard(_ course: CampusCourse) -> some View {
        NavigationLink { CourseDetailView(course: course) } label: {
            HStack(spacing: 14) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("下一节课").font(.caption).opacity(0.85)
                    Text(course.title).font(.title3.bold()).lineLimit(1)
                    Text("\(TermClock.time(course.startMinute))–\(TermClock.time(course.endMinute)) · \(course.location.isEmpty ? "教室未填写" : course.location)")
                        .font(.caption)
                        .opacity(0.9)
                        .lineLimit(1)
                }
                Spacer(minLength: 6)
                Image(systemName: "chevron.right").font(.caption)
            }
            .padding(14)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(CampusPalette.primary, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            .foregroundStyle(.white)
        }
        .buttonStyle(.plain)
    }

    private func reminderStrip(_ course: CampusCourse) -> some View {
        let effective = ClassReminder.offset(for: course)
        let text: String
        if let minutes = effective {
            text = "课前 \(minutes) 分钟提醒要上这节课"
        } else {
            text = "这节课不提醒"
        }
        return HStack(spacing: 6) {
            Image(systemName: "bell.badge").font(.caption2)
            Text(text).font(.caption2)
            if liveActivityEnabled {
                Text("· 灵动岛").font(.caption2)
            }
            Spacer()
        }
        .foregroundStyle(.secondary)
    }

    private func courseRow(_ course: CampusCourse) -> some View {
        NavigationLink { CourseDetailView(course: course) } label: {
            HStack(spacing: 12) {
                Text(TermClock.time(course.startMinute))
                    .font(.caption.bold()).monospacedDigit()
                    .foregroundStyle(CampusPalette.primary)
                    .frame(width: 42, alignment: .leading)
                VStack(alignment: .leading, spacing: 2) {
                    Text(course.title).font(.subheadline.weight(.medium)).lineLimit(1)
                    Text(course.location.isEmpty ? "教室未填写" : course.location)
                        .font(.caption).foregroundStyle(.secondary).lineLimit(1)
                }
                Spacer()
                Image(systemName: "chevron.right").font(.caption2).foregroundStyle(.tertiary)
            }
            .padding(.vertical, 8).padding(.horizontal, 10)
            .background(CampusPalette.card, in: RoundedRectangle(cornerRadius: 10, style: .continuous))
        }
        .buttonStyle(.plain)
    }

    private func taskRow(_ task: CampusTask) -> some View {
        let next = TaskSchedule.nextOccurrence(task) ?? task.dueAt
        let isDone = TaskSchedule.isDone(task)
        return HStack(spacing: 12) {
            Button {
                TaskSchedule.toggleDone(task)
                try? context.save()
                Task { await ReminderManager.rebuildFrom(context: context, termStart: termStartTimestamp > 0 ? termStart : .now) }
            } label: {
                Image(systemName: isDone ? "checkmark.circle.fill" : "circle")
                    .font(.title3)
                    .foregroundStyle(CampusPalette.primary)
                    .frame(width: 44, height: 44)
                    .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .accessibilityLabel(isDone ? "恢复\(task.title)" : "完成\(task.title)")
            VStack(alignment: .leading, spacing: 2) {
                Text(task.title).font(.subheadline.weight(.medium)).lineLimit(1)
                Text("\(next, format: .dateTime.month().day().hour().minute()) · \(TaskSchedule.summary(task))")
                    .font(.caption)
                    .foregroundStyle(next < .now ? Color.red : CampusPalette.muted)
                    .lineLimit(1)
            }
            Spacer()
        }
        .padding(.vertical, 8).padding(.horizontal, 10)
        .background(CampusPalette.card, in: RoundedRectangle(cornerRadius: 10, style: .continuous))
    }

    private func handle(_ service: CampusService) {
        if service == .shower,
           let saved = ShowerLinkStore.load(),
           let url = ExternalRoutes.showerURL(from: saved) {
            Task {
                if !(await UIApplication.shared.open(url)) { selectedService = service }
            }
        } else {
            selectedService = service
        }
    }
}
