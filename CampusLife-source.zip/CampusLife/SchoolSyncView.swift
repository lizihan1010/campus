import SwiftData
import SwiftUI
import WebKit

// MARK: - 网页容器

final class SchoolWebModel: NSObject, ObservableObject, WKNavigationDelegate {
    let webView = WKWebView()
    @Published var isLoading = false

    override init() {
        super.init()
        webView.navigationDelegate = self
        webView.allowsBackForwardNavigationGestures = true
    }

    func load() {
        guard let url = URL(string: "https://jwxt.jxufe.edu.cn/") else { return }
        webView.load(URLRequest(url: url))
    }

    func webView(
        _ webView: WKWebView,
        decidePolicyFor navigationAction: WKNavigationAction,
        decisionHandler: @escaping (WKNavigationActionPolicy) -> Void
    ) {
        guard let url = navigationAction.request.url else { decisionHandler(.allow); return }
        guard let scheme = url.scheme?.lowercased(), scheme == "http" || scheme == "https" else {
            decisionHandler(.allow)
            return
        }
        let host = url.host ?? ""
        // 只允许学校域名，防止被跳转到钓鱼页面
        if host.hasSuffix("jxufe.edu.cn") || host.hasSuffix("jxufe.cn") {
            decisionHandler(.allow)
        } else {
            decisionHandler(.cancel)
        }
    }

    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        isLoading = true
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        isLoading = false
    }
}

struct SchoolWebView: UIViewRepresentable {
    let webView: WKWebView

    func makeUIView(context: Context) -> WKWebView { webView }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

// MARK: - 同步主界面

struct SchoolSyncSheet: View {
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @AppStorage("termStartTimestamp") private var termStartTimestamp = 0.0

    @StateObject private var model = SchoolWebModel()
    @State private var status = "① 在下方页面登录（账号密码只在学校页面里输入）\n② 进入「教学安排 → 个人课表」，切到「列表」\n③ 点右上角「提取课表」"
    @State private var isExtracting = false
    @State private var result: SyncResult?

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                Text(status)
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(10)

                Divider()

                SchoolWebView(webView: model.webView)
            }
            .navigationTitle("从教务系统同步")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("关闭") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(isExtracting ? "识别中…" : "提取课表") { extract() }
                        .disabled(isExtracting)
                }
            }
            .onAppear { model.load() }
            .sheet(item: $result) { res in
                SyncPreviewView(result: res) {
                    apply(res)
                }
            }
        }
    }

    private func extract() {
        isExtracting = true
        model.webView.evaluateJavaScript(TimetableParser.extractionScript) { value, _ in
            isExtracting = false

            guard let json = value as? String, let data = json.data(using: .utf8) else {
                status = "没读到页面内容。请确认已经登录，并且停留在「个人课表」页面。"
                return
            }

            do {
                let payload = try JSONDecoder().decode(ExtractPayload.self, from: data)
                guard payload.ok else {
                    status = "没有找到课表。请先在页面里打开「教学安排 → 个人课表」。"
                    return
                }

                var best: (courses: [ParsedCourse], skipped: Int)?
                for table in payload.tables {
                    let parsed = TimetableParser.parse(rows: table)
                    if parsed.courses.count > (best?.courses.count ?? 0) {
                        best = parsed
                    }
                }

                guard let found = best, !found.courses.isEmpty else {
                    status = "课表是空的，或者页面结构变了。可先用截图 OCR 录入。"
                    return
                }

                let existing = (try? context.fetch(FetchDescriptor<CampusCourse>())) ?? []
                let plan = TimetableSync.plan(parsed: found.courses, existing: existing)
                result = SyncResult(courses: found.courses, plan: plan, skipped: found.skipped)
            } catch {
                status = "解析失败：\(error.localizedDescription)"
            }
        }
    }

    private func apply(_ res: SyncResult) {
        do {
            try TimetableSync.apply(res.plan, context: context)
            result = nil
            Task {
                await ReminderManager.rebuildFrom(
                    context: context,
                    termStart: termStartTimestamp > 0 ? Date(timeIntervalSince1970: termStartTimestamp) : .now
                )
            }
            dismiss()
        } catch {
            status = "写入失败：\(error.localizedDescription)"
        }
    }
}

// MARK: - 数据

struct SyncResult: Identifiable {
    let id = UUID()
    let courses: [ParsedCourse]
    let plan: TimetableSync.Plan
    let skipped: Int
}

private struct ExtractPayload: Decodable {
    let ok: Bool
    let tables: [[[String]]]
}

// MARK: - 预览

struct SyncPreviewView: View {
    let result: SyncResult
    let onApply: () -> Void

    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                Section("本次变化") {
                    LabeledContent("新增", value: "\(result.plan.added.count) 门")
                    LabeledContent("修改", value: "\(result.plan.updated.count) 门")
                    LabeledContent("移除", value: "\(result.plan.removed.count) 门")
                    LabeledContent("未变化", value: "\(result.plan.unchanged) 门")
                    if result.skipped > 0 {
                        LabeledContent("跳过（无固定时间）", value: "\(result.skipped) 门")
                    }
                }

                Section("识别到的课程（\(result.courses.count) 条）") {
                    ForEach(Array(result.courses.enumerated()), id: \.offset) { _, course in
                        VStack(alignment: .leading, spacing: 3) {
                            Text(course.title).font(.headline)
                            Text("\(weekdayName(course.weekday))  \(clock(course.startMinute))–\(clock(course.endMinute))")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            if !course.location.isEmpty {
                                Text(course.location)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                            Text("第 \(course.weeks.first ?? 1)–\(course.weeks.last ?? 20) 周，共 \(course.weeks.count) 周")
                                .font(.caption2)
                                .foregroundStyle(.tertiary)
                        }
                        .padding(.vertical, 2)
                    }
                }

                Section {
                    Text("导入后，教务系统来源的课程会被整体替换；你手动添加的课程不受影响。")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("同步预览")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("导入") { onApply() }
                }
            }
        }
    }

    private func weekdayName(_ weekday: Int) -> String {
        let names = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
        guard weekday >= 1, weekday <= 7 else { return "" }
        return names[weekday - 1]
    }

    private func clock(_ minute: Int) -> String {
        String(format: "%02d:%02d", minute / 60, minute % 60)
    }
}
