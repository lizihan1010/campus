import ActivityKit
import Foundation

/// App 与 Widget Extension 共用的实时活动数据结构。
/// 由 project.yml 同时加入两个 target 的 Compile Sources。
struct CourseActivityAttributes: ActivityAttributes {
    public struct ContentState: Codable, Hashable {
        var phase: String          // 下一节课 / 正在上课
        var courseTitle: String
        var location: String
        var startTime: String
        var endTime: String
        var targetAt: Date         // 倒计时目标（开课或下课时刻）
        var targetLabel: String    // 开课 / 下课
    }

    var source: String
}
