import ActivityKit
import SwiftUI
import WidgetKit

private let islandBlue = Color(red: 0.13, green: 0.40, blue: 0.82)

/// 锁屏 / 通知横幅样式：课程名 + 教室 + 倒计时
struct CourseLiveActivityView: View {
    let context: ActivityViewContext<CourseActivityAttributes>

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: "book.fill")
                .font(.title2)
                .foregroundStyle(islandBlue)
            VStack(alignment: .leading, spacing: 3) {
                Text(context.isStale ? "已下课" : context.state.phase).font(.caption).foregroundStyle(.secondary)
                Text(context.state.courseTitle).font(.subheadline.bold()).lineLimit(1)
                Text("\(context.state.startTime)–\(context.state.endTime) · \(context.state.location)")
                    .font(.caption).foregroundStyle(.secondary).lineLimit(1)
            }
            Spacer(minLength: 4)
            VStack(alignment: .trailing, spacing: 2) {
                if !context.isStale {
                    Text(context.state.targetLabel).font(.caption2).foregroundStyle(.secondary)
                    Text(context.state.targetAt, style: .relative)
                        .font(.caption.bold()).monospacedDigit()
                        .multilineTextAlignment(.trailing)
                }
            }
        }
        .padding(14)
        .activitySystemActionForegroundColor(.primary)
    }
}

struct CourseLiveActivityWidget: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: CourseActivityAttributes.self) { context in
            CourseLiveActivityView(context: context)
        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    Label(context.isStale ? "已下课" : context.state.phase, systemImage: "book.fill")
                        .font(.caption)
                        .foregroundStyle(islandBlue)
                }
                DynamicIslandExpandedRegion(.trailing) {
                    if context.isStale { Text("已下课").font(.caption.bold()) }
                    else { Text(context.state.targetAt, style: .relative).font(.caption.bold()).monospacedDigit() }
                }
                DynamicIslandExpandedRegion(.center) {
                    Text(context.state.courseTitle)
                        .font(.caption.bold())
                        .lineLimit(1)
                }
                DynamicIslandExpandedRegion(.bottom) {
                    HStack(spacing: 8) {
                        Text("\(context.state.startTime)–\(context.state.endTime)")
                        Text(context.state.location).lineLimit(1)
                    }
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                }
            } compactLeading: {
                Image(systemName: "book.fill").foregroundStyle(islandBlue)
            } compactTrailing: {
                Group {
                    if context.isStale { Text("已下课") }
                    else { Text(context.state.targetAt, style: .relative) }
                }
                .font(.caption2.bold()).monospacedDigit()
                .frame(maxWidth: 62)
                .minimumScaleFactor(0.7)
                .lineLimit(1)
            } minimal: {
                Image(systemName: "book.fill").foregroundStyle(islandBlue)
            }
            .keylineTint(islandBlue)
        }
    }
}

@main
struct CampusLiveActivityBundle: WidgetBundle {
    var body: some Widget {
        CourseLiveActivityWidget()
    }
}
