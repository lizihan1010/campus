# 江财生活台（iPhone 原生应用）

没有 Mac 的安装步骤见 [DEPLOY-WINDOWS.md](DEPLOY-WINDOWS.md)。

面向江西财经大学学生的个人课表、待办、通知收集和校园服务入口。界面使用 SwiftUI，课程、待办和收件箱使用 SwiftData 保存在手机本机。最低 iOS 17，目标设备为 iPhone 14 Pro Max / iOS 26.3。

## 已实现

- 今天：首页汇总当天课程、近期待办和常用服务入口。
- 一周课表：按教学周、单双周显示课程；可新增、编辑、删除；可从截图识别文字后逐门核对录入。
- 收件箱：粘贴 QQ/微信通知，或选择截图进行本机 OCR；用户确认后保存，可转为待办。
- 提醒：课程提前 15 分钟、待办按设定时间触发本地通知；修改或删除数据后重新安排。
- 服务入口：通过用户创建的快捷指令启动慧生活798、喜鹊儿等；修猫助手显示微信内签到操作指引。洗浴入口支持首次扫描保存设备二维码，此后尝试直接打开原服务的下单页。
- 本机备份：导出和导入 JSON，便于重新签名安装时保护数据。

## 当前接入边界

慧生活798和喜鹊儿的快捷指令只能保证尝试启动原 App。它不代表进入扫码页或课表页。修猫助手已被用户实际确认能完成签到，但独立 iOS App 直达其微信小程序页面的正式入口尚未取得，因此本版提供操作指引。洗浴入口保存的是二维码原始链接，由 iOS 请求打开；是否直达住理生活的对应设备下单页，需要真机验证。若二维码只含设备编号、链接会过期或原 App 不接收外部跳转，仍无法直达。应用不自动读取 QQ 群消息，也不代替用户签到或付款。

## 在 iPhone 上准备快捷指令

打开 iPhone 的“快捷指令”应用，新建以下三个快捷指令。每个指令只需一个“打开 App”操作，名称必须逐字相同：

| 快捷指令名称 | 打开的 App |
| --- | --- |
| 校园-学习通 | 学习通 |
| 校园-喝水 | 慧生活798 |
| 校园-课表 | 喜鹊儿 |

如果“打开 App”能选到创高体育，还可以创建 `校园-运动`，并在真机上测试。

## 绑定常用洗浴设备

在“今天”点击“洗澡”→“首次扫描设备二维码”，允许相机权限，对准住理生活水控机屏幕上的二维码并点按识别出的码。应用将二维码中的链接保存在本机钥匙串。以后点击“洗澡”→“打开洗浴下单页”，尝试由系统直接打开该设备的原服务页面。首次保存后请在设备旁验证页面上的设备编号是否正确，并确认“点击下单”和付款仍由你手动完成。若跳转失败，可以重新扫描绑定或移除入口；如果扫码结果不是可打开的链接，应用会提示，而不会把设备编号误当作支付链接。

## 无 Mac：使用 GitHub Actions 编译、Windows iLoader 安装

1. 在 GitHub 创建一个仓库。将本文件夹里的 `CampusLife` 源码目录、`project.yml` 和 `.github/workflows/build-ios.yml` 放在**仓库根目录**。不要上传包含账号等私密信息的原始录屏。
2. 打开仓库的 **Actions → Build iPhone IPA → Run workflow**。云端 macOS 会安装 XcodeGen、生成 Xcode 工程并编译。首次运行前需在 GitHub 仓库中允许 Actions。当前工作流使用 `macos-26` 和该镜像默认 Xcode。
3. 工作流成功后，在该次运行页面底部下载 `CampusLife-unsigned-IPA` artifact。解压 ZIP，得到 `CampusLife-unsigned.ipa`。
4. 在 Windows 安装 Apple 提供的 iTunes 驱动并用可传数据的 USB 线连接 iPhone。手机上点“信任此电脑”。在 iLoader 中登录你自己的 Apple 账号并确认设备出现在 **Devices** 区域。
5. 点击 iLoader 的 **Import IPA**，选择刚下载的 `.ipa`，由 iLoader 为你的设备签名并安装。第一次本地安装如果提示开发者模式，到 iPhone **设置 → 隐私与安全性 → 开发者模式** 开启，重启并确认后重试。这个选项可能要先触发设备配对或安装尝试才出现。
6. 打开“江财生活台”，进入“我的”设置学期第一周的周一，开启通知，再录入课程与待办。重新签名或换安装方式前，在“我的”导出 JSON 备份。

免费 Apple 账号的个人团队签名通常 7 天过期，需要重新签名安装。请保留相同的应用标识；如果安装工具更改标识，旧应用数据可能不会自动迁移，可用 JSON 备份恢复。GitHub Actions 只负责生成**未签名** IPA；当前 Windows 环境不能实际编译或真机验证，本工作流需要在你的 GitHub 仓库运行后检查结果。

免费个人团队还有每台设备最多 3 个已安装开发版 App 的限制。如果 iLoader 提示名额不足，先检查已有的侧载 App。JSON 备份可能包含私人通知内容，请保存在你信任的位置。

## 有 Mac 时

安装 Xcode 26.2 或更新版本和 XcodeGen，在项目根目录执行 `xcodegen generate`，用 Xcode 打开 `CampusLife.xcodeproj`。在 Signing & Capabilities 选自己的 Personal Team，启用自动签名，修改唯一 Bundle ID，连接 iPhone 并点 Run。

## 项目文件

- `CampusLife/Models.swift`：课程、待办和消息模型，周次计算。
- `CampusLife/TodayView.swift`、`ScheduleView.swift`、`InboxView.swift`、`SettingsView.swift`：四个主页面。
- `CampusLife/Editors.swift`、`TaskListView.swift`、`ScheduleImportView.swift`：编辑和导入流程。
- `CampusLife/ReminderManager.swift`：本地通知。
- `CampusLife/ExternalRoutes.swift`：快捷指令与第三方入口。
- `CampusLife/BackupManager.swift`：JSON 备份恢复。
- `.github/workflows/build-ios.yml`：云端无签名 IPA 构建。

## 真机验收清单

1. 设置学期后添加单周、双周和每周课程，切换周次，确认显示正确。
2. 创建待办并开启通知，锁屏等待提醒；修改截止时间和标记完成后，确认旧提醒不再出现。
3. 导入一张喜鹊儿课表截图，检查 OCR 文字，再逐门录入。
4. 从 QQ 复制一条通知，粘贴到收件箱，转成待办；再试一张截图。
5. 配置喝水、课表快捷指令，逐一验证能否打开正确的原 App；在洗浴设备前首次扫码绑定，之后确认“打开洗浴下单页”能否直达同一设备。
6. 从课程详情打开修猫助手指引，按微信内流程由本人完成扫码签到并核对结果。
7. 导出 JSON 备份，导入后确认课程、待办、收件箱和学期设置恢复。

## 技术依据

- [Apple：iOS 26.3 与 Xcode 支持](https://developer.apple.com/documentation/ios-iPados-release-notes/ios-ipados-26_3-release-notes)
- [Apple：运行快捷指令的 URL](https://support.apple.com/en-ie/guide/shortcuts/apd624386f42/10.0/ios/27)
- [Apple：个人团队签名限制](https://developer.apple.com/help/account/basics/about-your-developer-account)
- [Apple：开发者模式](https://developer.apple.com/documentation/xcode/enabling-developer-mode-on-a-device)
- [iLoader 官方网站](https://iloader.app/)
- [XcodeGen 项目格式](https://github.com/yonaskolb/XcodeGen/blob/master/Docs/ProjectSpec.md)
