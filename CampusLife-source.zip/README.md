# 江财生活台（精简版 + 自定义提醒）

面向江西财经大学学生的 iPhone 个人助手：课表、待办、通知整理与校园服务入口。SwiftUI + SwiftData + ActivityKit，iOS 17+，数据只存本机。

## 这一版按你的要求改了什么

| 变更 | 说明 |
| --- | --- |
| 首页常用入口 | 移除「扫码签到」「原课表」，恢复「运动」。现在只有 **喝水 / 运动 / 洗澡** 三个 |
| 原课表 | 服务与「校园-课表」快捷指令整体删除；课程在应用内手动管理 |
| 扫码签到 | 保留在**课程详情**里（修猫助手口令仍在「我的」），不再占用首页位置 |
| 课表界面 | 顶部周切换 + 横向 7 列课程卡片；点击进入详情，在详情中编辑或删除 |
| 课前提醒 | 可设置每堂课提前多少分钟通知（5/10/15/20/30/45/60），通知标题写明课程名、时间、教室；单门课可单独覆盖或关闭 |
| 灵动岛 | 新增 Widget Extension，用实时活动在灵动岛 / 锁屏显示「下一节课」或「正在上课」与倒计时 |
| 自定义待办 | 可以自己添加要做的事，选择 **只做一次 / 每周指定星期几 / 每隔 N 天**，每种都能设时间、起始日和提前提醒 |

## 功能

- **今天**：下一节课主卡（下方显示课前提醒设置）、当天课程与待办、三个常用入口
- **课表**：7 列周课表；点卡片进详情并可编辑或删除；右上角 + 手动加课
- **收件箱**：粘贴群通知或选截图本机 OCR，人工确认后转待办
- **全部待办**：显示重复规则和下一次执行时间；重复任务勾「完成」只记录当天，下个周期照常出现
- **我的**：学期 / 上课提醒 / 灵动岛 / 自定义待办 / 课程链接 / 服务入口 / 数据与备份
- **提醒**：课程按提前量、待办按每次执行日单独排本地通知；最多排未来 14 天、共 50 条，改动后自动重排

## 提醒与灵动岛怎么用

1. 「我的 → 上课提醒」打开开关，选提前分钟数。默认 15 分钟，全局生效。
2. 想让某一门课不一样，去「课表 → 课程详情 → 编辑课程 → 这节课的上课提醒」单独设置，也可以设为「不提醒」。
3. 「我的 → 灵动岛」打开开关，或点课程详情里的「在灵动岛显示这节课」。App 打开 / 回到前台时会自动刷新到当前该关注的课（正在上的课，或 4 小时内即将开始的课）。
4. 自定义待办：在「今天」或「全部待办」右上角点 +，选重复方式，设置时间与提前提醒。

**必须知道的三个限制**

- 灵动岛硬件上只存在于 iPhone 14 Pro 及以上机型；其他机型实时活动只出现在锁屏通知区。
- 本 App **没有推送服务器、没有 APNs 凭证**，实时活动只能在前台由 App 发起/更新（ActivityKit 明确禁止后台启动，除非用 `LiveActivityIntent`）。倒计时文本由系统持续更新，但「下一节课」的内容要等下次打开 App 才会切换。想进一步自动化，可后续加 App Intent 配合 iPhone 的快捷指令自动化；本版未实现。
- 没有伪造付款页、没有代签到、没有代付款；付款与签到仍由你本人在原服务确认。

## 安装（无 Mac）

1. 把 `CampusLife-source.zip` 放在仓库根目录（与 `.github/workflows/build-ios.yml` 同级）。推送后 Actions 自动构建，也可在 Actions 手动 **Run workflow**。
2. 打开**最近一次成功**的 *Build iPhone IPA* 运行页，在底部下载 `CampusLife-unsigned-IPA`，解压得到 `.ipa`。
3. Windows 上用 iTunes 驱动 + iLoader，登录自己的 Apple 账号，**Import IPA** 签名安装；首次按提示开启「开发者模式」。
4. 免费个人签名通常约 7 天过期；重装前先在「我的」导出 JSON 备份。

**Widget Extension 的签名提醒**：本版新增 `CampusLiveActivity` app extension，IPA 里会多一个 `PlugIns/CampusLiveActivity.appex`。若个人签名工具只重签主 App、不重签嵌套扩展，实时活动可能不显示（App 其余功能不受影响）。遇到这种情况请用 Xcode 选自己的 Personal Team 直接 Run 一次。

工作流使用 `macos-latest` + XcodeGen + `CODE_SIGNING_ALLOWED=NO`；`cp -R CampusLife.app Payload/` 会连同 PlugIns 一起打进 IPA，工作流本身不用改。有 Mac 时：`xcodegen generate` 后用 Xcode 打开 `CampusLife.xcodeproj`，选自己的 Team 后 Run。

## 在 iPhone 上准备快捷指令

在「快捷指令」里各建一个「打开 App」操作，名称必须逐字相同：

| 名称 | 打开的 App | 状态 |
| --- | --- | --- |
| 校园-学习通 | 学习通 | 课程详情里使用 |
| 校园-喝水 | 慧生活798 | 首页常用入口 |
| 校园-运动 | 创高体育 | 首页常用入口，**待真机验证** |

## 接入边界

- **课表管理**：本版不提供教务系统同步；已有课程数据保留，可手动添加和编辑。
- **学习通**：课程页链接含会话生成的 `enc`，会过期；绑定只在本机保存链接，不导出到备份。未绑定时点「学习通」只启动 App。
- **修猫助手**：`#小程序://修猫助手/ScC15pcInDDpQej` 是微信 Short Link 纯文本口令，只在微信内生效，独立 App 打不开。短期版本 30 天过期，失效后请在微信重新复制并更新 `WeChatShortLink.signIn`。
- **喝水**：设备参数只由慧生活798 的「扫一扫」解析，系统相机扫同一张码只会回首页；本版不做假的直达付款页。
- **洗浴**：默认设备 2153544，可扫码更换；下单与付款由本人确认。
- 本 App 不代签到、不代付款、不保存学习通或微信账号与人脸照片，不读取群聊后台。

## 项目文件

| 文件 | 作用 |
| --- | --- |
| `CampusLifeApp.swift` | 入口、四个 Tab、SwiftData 容器、回到前台时重排通知与刷新实时活动 |
| `Models.swift` | 课程 / 待办 / 收件箱 / 学习通绑定模型与教学周计算（新增课程提醒覆盖、待办重复字段） |
| `TodayView.swift`、`ScheduleView.swift`、`InboxView.swift`、`SettingsView.swift` | 四个主页面；课程详情在 `ScheduleView.swift` |
| `ClassReminder.swift`、`TaskSchedule.swift`、`ReminderManager.swift` | 课前提醒设置、待办重复规则计算、本地通知排程 |
| `LiveActivityManager.swift` | 实时活动的启动、刷新与结束 |
| `CampusLiveActivity/CourseActivityAttributes.swift` | App 与 Widget 共用的活动数据结构 |
| `CampusLiveActivity/CampusLiveActivityWidget.swift`、`Info.plist` | 灵动岛 / 锁屏视图与扩展配置 |
| `Editors.swift`、`TaskListView.swift` | 课程 / 待办编辑器（含重复方式选择）与完整待办列表 |
| `ExternalRoutes.swift` | 三个常用入口、微信 Short Link、快捷指令、洗浴扫码 |
| `CampusPalette.swift`、`ChaoxingView.swift` | 配色与通用组件、系统 Safari 视图与学习通绑定 |
| `BackupManager.swift`、`ShowerLinkStore.swift` | JSON 备份（含新字段，兼容旧备份）、钥匙串 |
| `project.yml` | XcodeGen 配置：主 App + `CampusLiveActivity` 扩展 |

## 真机验收清单

1. 设置学期起始周，确认首页教学周与课表周次一致；课表界面是原来的 7 列大卡片。
2. 首页常用入口只有喝水 / 运动 / 洗澡；点「运动」能启动「校园-运动」快捷指令。
3. 「我的 → 上课提醒」分别设 5 / 15 / 30 分钟，锁屏确认通知标题写出课程名、时间与教室；把某门课设为「不提醒」后确认只有它不再提醒。
4. 在 iPhone 14 Pro 及以上机型打开 App，确认灵动岛 / 锁屏出现「下一节课」和倒计时；锁屏放置一段时间看倒计时是否继续更新；重新打开 App 确认切换到当前该关注的课。
5. 添加三种待办各一条：只做一次、每周一三五、每隔 3 天；分别等到提醒时间确认通知；勾完成后确认重复任务下一次照常出现。
6. 从课表右上角 + 手动添加课程；点卡片进详情，确认编辑、删除、「扫码签到」与「学习通」入口。
7. 从 QQ 复制一条通知粘贴到收件箱转待办；再试一张截图 OCR。
8. 配置三条快捷指令并逐一验证；点「洗澡」确认是否进入设备 2153544 的下单页。
9. 导出 JSON 备份后导入，确认课程（含同步来源、周次列表、提醒覆盖）、待办（含重复规则）、收件箱与学期设置恢复。

## 升级提示

新增了 SwiftData 属性（课程 `reminderOverride`，待办 `repeatKind / repeatWeekdays / repeatInterval / startDate / doneDates`），属于轻量迁移；**升级前先在「我的」导出 JSON 备份**。旧备份可正常导入，其中待办按「只做一次」读取。

## 技术依据

- [Apple：ActivityKit / Live Activities](https://developer.apple.com/documentation/activitykit)
- [Apple：运行快捷指令的 URL](https://support.apple.com/en-ie/guide/shortcuts/apd624386f42/10.0/ios/27)
- [Apple：个人团队签名限制](https://developer.apple.com/help/account/basics/about-your-developer-account)
- [Apple：开发者模式](https://developer.apple.com/documentation/xcode/enabling-developer-mode-on-a-device)
- [微信开放文档：获取 Short Link](https://developers.weixin.qq.com/miniprogram/dev/framework/open-ability/shortlink.html)
- [XcodeGen 项目格式](https://github.com/yonaskolb/XcodeGen/blob/master/Docs/ProjectSpec.md)
