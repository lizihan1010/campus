# 没有 Mac：把江财生活台装到 iPhone

这份步骤对应你目前的 Windows 电脑、iPhone 14 Pro Max（iOS 26.3）和已安装的 iLoader。GitHub 的 macOS 机器负责编译，iLoader 在你的 Windows 电脑上签名安装。

## 第一次构建

1. 准备一个 GitHub 账号，在 GitHub 网页创建一个**空的私有仓库**，例如 `campus-life-ios`。暂时不勾选自动添加 README。
2. 在 Windows 打开本项目文件夹 `CampusLife`。仓库根目录必须直接包含 `project.yml`、`README.md`、`CampusLife` 源码目录和 `.github` 目录。
3. 如果已安装 Git，在此文件夹打开 PowerShell，依次运行：

   ```powershell
   git init
   git add .
   git commit -m "Add CampusLife iPhone app"
   git branch -M main
   git remote add origin https://github.com/你的用户名/campus-life-ios.git
   git push -u origin main
   ```

   把远程地址替换为 GitHub 上刚创建的私有仓库地址。浏览器可能会要求你登录 GitHub。也可以让 WorkBuddy 帮你把**本文件夹的内容**上传到仓库根目录。

4. 在 GitHub 仓库点 **Actions**。找到 **Build iPhone IPA**，点 **Run workflow**。如果第一次需要启用 Actions，按仓库提示启用。
5. 等待 `build` 任务出现绿色勾。打开该次运行，下载页面底部的 `CampusLife-unsigned-IPA`。解压 ZIP 后得到 `CampusLife-unsigned.ipa`。
6. 如果任务显示红叉，打开失败步骤，把错误日志发给我或 WorkBuddy。不要把 Apple ID 密码、验证码或签名证书放入 GitHub 仓库或聊天记录。

## 在 Windows 安装到手机

1. 用支持数据传输的线连接 iPhone，解锁手机，点击 **信任此电脑**。先确认 iTunes 能看到手机图标。
2. 打开 iLoader。如果它显示 **No devices found**，先检查线、USB 口、iTunes 驱动和手机上的信任提示，然后点 **Refresh**。
3. 在 iLoader 登录自己的 Apple 账号，选中 iPhone，点击 **Import IPA**，选择 `CampusLife-unsigned.ipa`。按 iLoader 的提示签名和安装。
4. 如果手机提示需要开发者模式，到 **设置 → 隐私与安全性 → 开发者模式** 开启，重启后输入锁屏密码确认。这个入口通常在设备与开发工具配对或首次安装尝试后才出现。
5. 回到主屏幕打开 **江财生活台**。在 **我的** 设置学期第一周的周一，并开启通知。首次测试请添加一门课和一个几分钟后提醒的待办。

## 后续更新和数据

- 改完代码推送到 GitHub，重新运行工作流，下载新的 IPA，并用 iLoader 更新。
- 免费 Apple 账号的安装签名约 7 天到期，需要定期重新签名。免费个人团队每台设备最多安装 3 个开发版 App。
- **每次更换签名方式或重装前，在 App → 我的 → 生成 JSON 备份 → 分享或保存备份。** 如果安装工具改变了 App 标识，旧数据可能不会自动跟过来。安装后可在同一页导入备份。
- JSON 备份含课程、待办和你粘贴的群通知，保存在你信任的位置。
- 本项目尚未在这台 Windows 电脑上完成 iOS 编译或真机测试；首次云端构建结果决定下一步是否需要修复代码。

## 官方依据

- [Apple：iOS 26.3 SDK 与 Xcode](https://developer.apple.com/documentation/ios-iPados-release-notes/ios-ipados-26_3-release-notes)
- [Apple：个人团队 7 天签名与 3 App 限制](https://developer.apple.com/help/account/basics/about-your-developer-account)
- [Apple：开发者模式为何可能暂时不显示](https://developer.apple.com/documentation/xcode/enabling-developer-mode-on-a-device)
- [iLoader：Windows、导入 IPA 和签名](https://iloader.app/)
