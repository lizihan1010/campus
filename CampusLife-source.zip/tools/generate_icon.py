from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "CampusLife" / "Assets.xcassets" / "AppIcon.appiconset" / "AppIcon.png"
SIZE = 1024

image = Image.new("RGB", (SIZE, SIZE))
pixels = image.load()
for y in range(SIZE):
    for x in range(SIZE):
        t = (x + y) / (2 * SIZE)
        pixels[x, y] = (round(32 + 25 * t), round(96 + 37 * t), round(198 + 31 * t))

glow = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
g = ImageDraw.Draw(glow)
g.ellipse((600, -180, 1300, 520), fill=(180, 225, 255, 80))
glow = glow.filter(ImageFilter.GaussianBlur(95))
image = Image.alpha_composite(image.convert("RGBA"), glow)

draw = ImageDraw.Draw(image)
draw.rounded_rectangle((225, 210, 800, 815), radius=115, fill=(255, 255, 255, 245))
draw.rounded_rectangle((225, 210, 800, 355), radius=110, fill=(20, 85, 191, 255))
draw.rectangle((225, 280, 800, 355), fill=(20, 85, 191, 255))
draw.rounded_rectangle((330, 160, 390, 275), radius=30, fill=(238, 247, 255, 255))
draw.rounded_rectangle((635, 160, 695, 275), radius=30, fill=(238, 247, 255, 255))
draw.line([(338, 565), (465, 685), (700, 445)], fill=(34, 128, 208, 255), width=66, joint="curve")
draw.ellipse((780, 660, 940, 820), fill=(123, 220, 205, 255))
draw.ellipse((820, 700, 900, 780), fill=(255, 255, 255, 255))
image.convert("RGB").save(OUT, quality=95)
print(OUT)
