"""Static packaging checks for Windows hosts without Xcode.

This does not compile Swift. GitHub Actions performs the iOS build.
"""

from pathlib import Path
import json
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
SOURCES = ROOT / "CampusLife"
swift_files = sorted(SOURCES.glob("*.swift"))
assert len(swift_files) >= 10, "Swift files missing"
assert (SOURCES / "CampusLifeApp.swift").exists(), "App entry missing"
assert (ROOT / "project.yml").exists(), "XcodeGen spec missing"
assert (ROOT / ".github/workflows/build-ios.yml").exists(), "Cloud build workflow missing"

for source in swift_files:
    content = source.read_text(encoding="utf-8")
    assert content.strip(), f"Empty file: {source.name}"
    assert "fatalError(" not in content, f"Unsafe placeholder: {source.name}"
    assert content.count("{") == content.count("}"), f"Unbalanced braces: {source.name}"

icon_dir = SOURCES / "Assets.xcassets/AppIcon.appiconset"
data = json.loads((icon_dir / "Contents.json").read_text(encoding="utf-8"))
icon = icon_dir / data["images"][0]["filename"]
with Image.open(icon) as image:
    assert image.size == (1024, 1024), "App icon size is wrong"

project = (ROOT / "project.yml").read_text(encoding="utf-8")
workflow = (ROOT / ".github/workflows/build-ios.yml").read_text(encoding="utf-8")
assert "iOS: \"17.0\"" in project
assert "CampusLife:" in project
assert "CODE_SIGNING_ALLOWED=NO" in workflow
assert "CampusLife-unsigned.ipa" in workflow
assert "runs-on: macos-26" in workflow

print(f"PASS: {len(swift_files)} Swift files, app icon, XcodeGen spec and unsigned IPA workflow")
